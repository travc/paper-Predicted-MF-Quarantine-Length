/**
 * Created 22 Oct 2013
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 */
package gov.usda.ars.medfoesp;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;

import gov.usda.ars.medfoes.Simulation;

/**
 * Class that manages running a single MED-FOES simulation. 
 * 
 * @author manoukis
 *
 */
public class SimRunner implements Runnable{
	
	String [] p; //parameters for current run
	Simulation s; //simulation currently running
	Tasker t; // the tasker (same object for all SimRunners)
	ResultHolder r;  // the object that holds results. Report to this.
	CountDownLatch c; //sync threads
	
	/**
	 * Constuctor for making a SimRunner object.
	 * 
	 * @param t Tasker that provides command lines (Master)
	 * @param r ResultHolder for returning results to (Consumer)
	 * @param c CountDownLatch to report to when complete
	 */
	public SimRunner(Tasker t, ResultHolder r, CountDownLatch c){
		this.t=t;
		this.r=r;
		this.c=c;
	}
	
	/**
	 * Run method for starting a thread.
	 */
	public void run() {
		// here we run simulations until we run out of parameter sets.
		while (true){
			this.p=t.getParamSet();
			if (p.length>1){
				s = new Simulation();
				s.setSharedParams(this.t.T);
				s.run(this.p);
				//System.out.println("summary: "+s.outputSummaryForMedfoesp()[0]+"\t"+s.outputSummaryForMedfoesp()[1]);
				r.AddSummaryResults(s.outputSummaryForMedfoesp());
			}
			else{
				System.out.println("Thread "+this.toString()+" completed.");
				c.countDown();
				break;
			}
		}
		
	}
	
	


}
