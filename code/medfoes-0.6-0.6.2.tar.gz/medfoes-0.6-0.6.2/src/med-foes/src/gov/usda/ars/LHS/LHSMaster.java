/**
 * Created 2 December 2011
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 */
package gov.usda.ars.LHS;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Formatter;
import java.util.Properties;

/**
 * 
 * 
 * @author manoukis
 *
 */
public class LHSMaster {

	/**
	 * @param args
	 */
	
	ArrayList params;
	String infile;
	Properties p;
	int nSlices;
	String pre;
	String post;
	
	public static void main(String[] args) {
		
		if (args.length<3){
			System.err.println("ERROR in Master::main : require these arguments: LHSMaster <nreps> <data to prepend> <infile with parameter ranges> <data to append>");
			System.err.println("The only optional argument is the last one, <data to append>");
			System.exit(1);
		}
		
		
		LHSMaster m = new LHSMaster();
		m.nSlices=Integer.parseInt(args[0]); 
		m.pre=args[1];
		if (args.length>3){
			m.post=args[3];
		}
		m.run(args);
		

	}


	/**
	 * Generates the parameters. Note that nSlices , pre and (optionally) post must already be set. Will read in infile here
	 * @param args from command line.
	 * @return the commands
	 */
	public String [] run(String [] args) {
		this.params= new ArrayList();
		this.infile=args[2];
		loadparameters(infile);
		String [] out = new String [p.size()];
		
		Enumeration en = p.keys();
		int i=0;
		 // how much zero padding we will need. Note that runs numbers start at 0.
		int maxdigits= Integer.toString(nSlices).length();
		
//		if (Integer.parseInt(nSlicesStr.substring(0,1))==1){
//			int s = 0;
//			for (int h=1;h<nSlicesStr.length()-1;h++){
//				s+=Integer.parseInt(nSlicesStr.substring(h,h+1));
//			}
//			if (s!=0){
//				maxdigits++;
//			}
//		}
		// end zero padding stuff
		
		while(en.hasMoreElements()){
			out[i]=generateParameterSets((String)en.nextElement());
			//System.out.println(out[i]);
			i++;
		}
		
		String [] [] all = new String [out.length] [nSlices];
		// now write it
		for (int j = 0;j<out.length;j++){
			all [j] = out[j].split(";");
		}
		
		for (int x=0;x<nSlices;x++){
			System.out.print(pre+" ");
			for (int y=0;y<all.length;y++){
				System.out.print(all[y][x]+" ");
			}
			if (post != null){
				System.out.print(post);
			}
			System.out.print(String.format("%"+ Integer.toString(maxdigits)+"s",Integer.toString(x)).replace(' ', '0')); // to append run number information;
			
			System.out.print("\n");
		}
		
		/**
		for (int i=0;i<out.length;i++){
			//populate output String array
			out[i]=generateParameterSets()
			
		}
		**/
		
		return out;
		
	}



	public String getPre() {
		return pre;
	}


	public void setPre(String pre) {
		this.pre = pre;
	}


	public String getPost() {
		return post;
	}


	public void setPost(String post) {
		this.post = post;
	}


	public int getnSlices() {
		return nSlices;
	}


	public void setnSlices(int nSlices) {
		this.nSlices = nSlices;
	}


	private void loadparameters(String inputFile) {
		
		try {
			FileInputStream is = new FileInputStream(inputFile);
			p = new Properties();
			p.load(is);	
			
			
		}
		catch (FileNotFoundException ex)
		{
			System.out.println("ERROR in Master::loadParameters : infile: " + inputFile+" not found");
			ex.printStackTrace();
			System.exit(1);
		} catch (IOException e) {
			System.out.println("ERROR in Master::loadParameters : problem parsing infile: " + inputFile);
			e.printStackTrace();
			System.exit(1);
		}
		
	}


	// method below needs to be able to handle options with more than one value- i.e TEL, etc. Suggest that
	// infile for LHS should have options as follows:
	
	/**
	 * 
	 * parameter split char = ';'
	 * -Ne	100,2500
	 * (etc)
	 * -TEL	6.2,9.8,100,155 - grouped by pairs, so that output is -TEL [from [0:1]] [from [2:3]]
	 */
	
	
	public String generateParameterSets(String Key){
		String out = "";
		
		String [] values = p.getProperty(Key).split(",");
		
		if (values.length==1){ // Do not vary this parameter!
			for (int j=0;j<nSlices;j++){
				out+=Key+" "+p.getProperty(Key)+";";
			}
		}
		
		else if (values.length==2){ // common case
			Parameter p = new Parameter(Double.parseDouble(values[0]),Double.parseDouble(values[1]),nSlices,Key);
			for (int j=0;j<nSlices;j++){
				out+=Key+" "+p.getRandomValue()+";";
			}
		}
		else if(values.length==4){ //special for med-foes - this is not the right way to handle this, but it will work
			Parameter p = new Parameter(Double.parseDouble(values[0]),Double.parseDouble(values[1]),nSlices,Key);
			Parameter p1= new Parameter(Double.parseDouble(values[2]),Double.parseDouble(values[3]),nSlices,Key);
			for (int j=0;j<nSlices;j++){
				out+=Key+" "+p.getRandomValue()+","+p1.getRandomValue()+";";
			}
		}
		
		else{
			System.out.println("ERROR in Master::generateParameterSets : all parameters must have only 1, 2 or 4 comma separated values. ");
		}
		
		
		//probably a better arrangement would involve something like this:
		/**
		for (int i=0;i<values.length;i=i+2){
			Parameter p = new Parameter(Double.parseDouble(values[i]),Double.parseDouble(values[i+1]),nSlices,Key);
			for (int j=0;j<nSlices;j++){
				out+=Key+" "+p.getRandomValue()+" ";
			}
			
		}
		*/
		
		
		return out;
	}

}
