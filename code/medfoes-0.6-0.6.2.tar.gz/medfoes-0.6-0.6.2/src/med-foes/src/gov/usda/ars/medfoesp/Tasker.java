/**
 * Created 22 Oct 2013
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 */
package gov.usda.ars.medfoesp;

/**
 * 
 * Master program that tasks SimRunners
 * @author manoukis
 *
 */
public class Tasker {
	
	String [] allParameters;
	// pre-loaded/computed data which is accessed in a read-only manner
	double [] T; // Hourly Temperatures. Length = maximum simulation run time
	// housekeeping and output
	int numRuns;
	int thisRun;

	public Tasker(String [] allParameters, double [] T){
		this.allParameters=allParameters;
		this.numRuns=allParameters.length;
		this.thisRun=0;
		this.T = T;
	}
	
	/**
	 * Get a parameter set to run
	 * @return a parameter set or a String[] length 1 (indicates all params done)
	 */
	public synchronized String [] getParamSet(){
		String [] out=null;
		if (thisRun==numRuns){
			out=new String []{"endruns"};
		}
		else{
			out =allParameters[thisRun].substring(12).split(" ");
			thisRun++;
		}
		
		return out;
	}
	
	
	/**
	 * Check how many runs remaining
	 * @return number of runs remaining
	 */
	public int getRunsRemaining(){
		return numRuns-thisRun;
	}

}
