/**
 * Created 27 July 2011
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 */
package gov.usda.ars.medfoes;

/**
 * Returns probability of an event under a linear model - Temperature dependent transition probabilities will come from here
 * 
 * 
 * @author manoukis
 *
 */
public class LmProbGenerator {
//	double Intercept;	//base temp
//	double Slope;		// slope- should be self exp
//	double Temp;		// the temp at which the event is occurring. Will affect probability that is returned, of course.
	Utilities u;

	
	public LmProbGenerator(Utilities u){
		this.u=u;
	}
	
	/**
	 * Calculates if a fly will transition from one stage to another, given a base temperature, slope and current temperature;
	 * Uses a uniform transition probability distribution
	 * @param Temp The current temperature
	 * @param Intercept intercept of linear model 1/d ~ T
	 * @param Slope slope of linear model 1/d ~ T
	 * @return Whether transition occurs. true=transition occurs.
	 */
	public Boolean getTransitionFlagUnifrom(double Temp, double Intercept, double Slope){
		double DevRate=Intercept+(Temp*Slope); // this is the developmental rate per time for this temp
//		double DevRate= 1/ExpectedTime; // the developmental rate per time period
		Boolean ret=true;
		// draw the probability of transition
		if(u.nextDouble()>DevRate/24){
			ret=false;
		}
		
		return ret;
	}
	


}
