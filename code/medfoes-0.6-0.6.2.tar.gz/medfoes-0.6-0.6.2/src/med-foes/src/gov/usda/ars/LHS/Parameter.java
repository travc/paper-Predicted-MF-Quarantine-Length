/**
 * 
 * Created 2 December 2011
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 */
package gov.usda.ars.LHS;

import java.util.ArrayList;

import gov.usda.ars.medfoes.Utilities;

//import java.math.BigDecimal;

/**
 * @author manoukis
 *
 */
public class Parameter {
	double min;
	double max;
	int nSlices;
	double sizeOfRange;
	ArrayList<Double> ranges;
	String name;
	Utilities u;

	
	public Parameter (double min, double max, int nSlices, String name){
		this.nSlices=nSlices;
		this.max=max;
		this.min=min;
		this.name=name;
		this.u=new Utilities();
		//u.initSeed();
		u.setSeed(45436545); //TODO- somehow use the same seed that will be used in simulations.
		
		// quick check
		if (min>max){
			System.err.println("ERROR in gov.usda.ars.LHS::Parameter::Parameter : min value is equal or"+
					"larger than max \n Exiting");
			System.exit(1);
		}
		
		//catch if min=max- this results in NO VARIATION
		if (min!=max){
			computeRanges(nSlices);
		}
		
		
		
	}
	


	/**
	 * Create a list of all the parameters that can be used
	 * @param numSimulations number of simulations to be run
	 */
	public void computeRanges(int numSimulations) {
		ranges = new ArrayList<Double>();
		double total = max - min;
		sizeOfRange = (double)total/numSimulations;
		//System.out.println(name);
		for (double i =min;i<max ;i+=sizeOfRange )
		{
			i = Utilities.round(i,10);
			ranges.add(new Double(i));
			//System.out.println(new Double(i));
		}

	}
	
	/**
	 * select one of the values within the range, at random
	 * @return a parameter value
	 */
	public double getRandomValue(){
		double rdouble;
		if (min==max){
			rdouble=min;
		}
		else{
		//System.out.println(this + " size" + ranges.size());
		int index = u.nextInt(ranges.size());
		double min = ((Double)ranges.remove(index)).doubleValue();
		//double max = min + sizeOfRange;
		rdouble = u.nextDouble();
		rdouble*=sizeOfRange;
		rdouble%=sizeOfRange;
		rdouble+=min;
		//System.out.println(this + " " +min);
		}
		return rdouble;
	}
	
	
}
