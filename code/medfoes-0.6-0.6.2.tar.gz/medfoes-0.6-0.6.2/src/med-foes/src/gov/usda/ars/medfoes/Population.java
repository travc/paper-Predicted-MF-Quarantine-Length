/**
 * Created 22 July 2011
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 */
package gov.usda.ars.medfoes;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

/**
 * The object for a population of flies during an outbreak in the MED-FOES simulation system
 * 
 * 
 * @author manoukis
 *
 */
public class Population {
	
	private ArrayList<Fly> Flies;		// array to hold all the flies.
	
	public Simulation s; //
	
	double [] Temperatures; // array of the HOURLY temperatures that the flies will experience from time of 
						// find to end of quarantine + 90 days. These may be fed in directly or be calculated from
						// min-max DAILY temperatures.
	double CurrentTemp; // the temperature at this tick (HOUR).
	LmProbGenerator lmp;
	MalletRandom mr;
	int EggsToAdd; 		// eggs to add to the population after regular aging (pooled from all flies)
	// temp dep mortalities by stage are calculated and held here.
	double CurrentTempDepMortalityEggs;
	double CurrentTempDepMortalityLarvae;
	double CurrentTempDepMortalityPupae;
	double CurrentTempDepMortalityAdults;
	
	

	int deadFlies; // the number of flies that have died so far (cumulative)
	int eggsLaid;	// the cumulative number of eggs laid.
	
	public int getNumberOfFlies(){
		return Flies.size();
	}

	/**
	 * Generate a Population
	 * @param s The parent simulation
	 * @param lmp lmProbGenerator for calculating stage transitions	
	 * @param Temperatures Array of hourly temperatures
	 */
	public Population(Simulation s, LmProbGenerator lmp, double [] Temperatures){
		this.Temperatures=Temperatures;
		this.s=s;
		this.lmp=lmp;
		this.mr = new MalletRandom();
		
		// set seed
		mr.setSeed(s.seed);
		
	//	if(s.seed!=null){
	//		mr.setSeed(s.seed);
	//	}
			// use InitializePopulation to get stable age structure 
			//given a certain number of adult flies in the find
//		this.Flies=new ArrayList();
//		for (int i=0;i<PopSize;i++){ 
//			Flies.add(new Fly(s.TEL[0], s.TEL[1],s.TIM[0],s.TIM[1],this,this.lmp));
//		}
		this.EggsToAdd=0;
		this.deadFlies=0;
		this.eggsLaid=0;

	}
	
	
	/**
	 * Advance the population by one time tick (hour)
	 */
	public void step(){
		setCurrentTemp(this.Temperatures[s.hours]); //TODO: need to make sure that if we run out of temps we can handle this gracefully!
		
		// update temperature-dependent daily mortality rates each tick. Relationships are for meds only, from Gutierrez and Ponti 2011
		this.CurrentTempDepMortalityEggs = (.0004*Math.pow(CurrentTemp, 2))-(.0145*CurrentTemp)+.1314;
		this.CurrentTempDepMortalityLarvae = (.0004*Math.pow(CurrentTemp, 2))-(.0145*CurrentTemp)+.1314;
		this.CurrentTempDepMortalityPupae=(.0005*Math.pow(CurrentTemp, 2))-(.0207*CurrentTemp)+.2142;
		this.CurrentTempDepMortalityAdults=(.00049*Math.pow(CurrentTemp, 2))-(.0187*CurrentTemp)+.1846;
		
		
		Iterator i = Flies.iterator();
		
		// Age all the flies, one at a time. Stage transitions that occur will occur here. Death might also occur here.
		while(i.hasNext()){
			((Fly) i.next()).Age();
		}
		
		// clean out the dead flies. May want to track when they died.
		Iterator j = Flies.iterator();
		while(j.hasNext()){
			if(((Fly) j.next()).Dead!=0){
				deadFlies++;
				j.remove();
			}
		}
		
		// If any of the flies have laid eggs, add them in here.
		
		
		
		if (s.hours/24>s.R){
			for (int f=0;f<EggsToAdd;f++){
				Flies.add(new Fly(s.TEL[0], s.TEL[1],s.TIM[0],s.TIM[1],this,this.lmp,s.DevModel,s.TuSD,s.Tmax,!s.SterileAfterIntervention));
			}
			eggsLaid+=EggsToAdd;
		}
		else{
			for (int f=0;f<EggsToAdd;f++){
				Flies.add(new Fly(s.TEL[0], s.TEL[1],s.TIM[0],s.TIM[1],this,this.lmp,s.DevModel,s.TuSD,s.Tmax,true));
			}
			eggsLaid+=EggsToAdd;
		}
		
		
		this.EggsToAdd=0; // reset at end of generation
		
//		// if the number of flies reaches zero, stop the simulation
//		if(Flies.size()==0){
//			s.exitSimulation();
//		}		
	}
	
	
	/**
	 * Count the number of flies in a given stage
	 * @param stage 0=eggs, 1=larvae, 2=pupae, 3=adults
	 * @return the number in that stage
	 */
	public int getNumberByStage(int stage){
		int out = 0;
		Iterator j = Flies.iterator();
		while(j.hasNext()){
			if(((Fly) j.next()).Stage==stage){
				out++;
			}
		}
		return out;
	}
	
	/**
	 * Initialize the population based on a given number of adult flies expected to be in the population
	 * plus an arbitrary stable age distribution.  
	 * @param Ni Estimated number of adults (mature + immature)
	 * @param frequencies percentages of individuals in each class: pos0=eggs, pos1=larvae, pos2=pupae, pos3=immature adults pos4=mature adults
	 */
	public void InitializePopulation (int Ni, double [] frequencies){
		
		
		int [] results = new int [5]; // pos0=eggs, pos1=larvae, pos2=pupae, pos3=immature adults
									  // pos4=mature adults
		
		double NumOnePct = (double)Ni/(frequencies[3]+frequencies[4]);
		
		results[0]=(int)Math.round(NumOnePct*frequencies[0]);
		results[1]=(int)Math.round(NumOnePct*frequencies[1]);
		results[2]=(int)Math.round(NumOnePct*frequencies[2]);
		results[3]=(int)Math.round(NumOnePct*frequencies[3]);
		results[4]=(int)Math.round(NumOnePct*frequencies[4]);
		
		this.Flies=new ArrayList();
		int stage=0;
		
		// check if some optional values have been set
		if(s.DevModel==0|s.DevModel==1){
			//pass
		}
		else{
			s.DevModel=0; //default
		}
		
		
		
		if (s.Tmax==0){
			s.Tmax=35;
		}
		//end checks for optionals
		
		// add all immature stages
		for (int i=0; i<4;i++){
			for (int j=0;j<results[i];j++){
				Flies.add(new Fly(s.TEL[0], s.TEL[1],s.TIM[0],s.TIM[1],this,this.lmp,stage,0,s.DevModel,s.TuSD,s.Tmax,true));
				eggsLaid++;
			}
			stage++;
		}
		// add mature flies
		
		for (int y=0;y<results[4];y++){
			Flies.add(new Fly(s.TEL[0], s.TEL[1],s.TIM[0],s.TIM[1],this,this.lmp,3,1,s.DevModel,s.TuSD,s.Tmax,true));
			eggsLaid++;
		}
		
	}
	
	
	
	/**
	 * Initialize the population based on a given number of adult flies expected to be in the population
	 * and the expected stable age distribution derived by Carey (1982), Table III. We
	 * set the proportion adults that are sexually mature to be those that are 'mid-age'
	 * and 'old-age'. Ni is all adults ('pre-ovipositional', and the two classes previously mentioned.
	 * @param Ni Estimated number of adults (mature + immature)
	 */
	public void InitializePopulation(int Ni){
		// Ni = 4.9 % of population. Of these, 62.8 % are sexually mature.
		
		int [] results = new int [5]; // pos0=eggs, pos1=larvae, pos2=pupae, pos3=immature adults
									  // pos4=mature adults
		
		double NumOnePct = (double)Ni/4.9;
		
		results[0]=(int)Math.round(NumOnePct*29.8);
		results[1]=(int)Math.round(NumOnePct*49.7);
		results[2]=(int)Math.round(NumOnePct*15.6);
		results[3]=(int)Math.round(NumOnePct*(4.9*0.372));
		results[4]=(int)Math.round(NumOnePct*(4.9*0.628));
		
		this.Flies=new ArrayList();
		int stage=0;
		
		// check is some optional values have been set
		if(s.DevModel==0|s.DevModel==1){
			//pass
		}
		else{
			s.DevModel=0; //default
		}
		
		
		if (s.Tmax==0){
			s.Tmax=35;
		}
		//end checks for optionals
		
		// add all immature stages
		for (int i=0; i<4;i++){
			for (int j=0;j<results[i];j++){
				Flies.add(new Fly(s.TEL[0], s.TEL[1],s.TIM[0],s.TIM[1],this,this.lmp,stage,0,s.DevModel,s.TuSD,s.Tmax,true));
				eggsLaid++;
			}
			stage++;
		}
		// add mature flies
		
		for (int y=0;y<results[4];y++){
			Flies.add(new Fly(s.TEL[0], s.TEL[1],s.TIM[0],s.TIM[1],this,this.lmp,3,1,s.DevModel,s.TuSD,s.Tmax,true));
			eggsLaid++;
		}
		
	}
	
	
	/**
	 * Returns the number of flies in each stage- a string with 
	 * number of the following, in order:
	 * eggs,larvae,pupae,immature adults, mature adults
	 * 
	 * @return number in each developmental class
	 */
	public String numberInEachStage(){
		String out = "";
		Iterator i = Flies.iterator();
		
		int [] res = new int [5];
		
		while(i.hasNext()){
			Fly j = (Fly) i.next();
			
			if(j.Stage==0){
				res[0]++;
			}
			if(j.Stage==1){
				res[1]++;
			}
			if(j.Stage==2){
				res[2]++;
			}
			if(j.Stage==3){
				if (j.Mature==0){
					res[3]++;
				}
				else {
					res[4]++;
				}
			}
			
		}
		
		for (int g=0;g<res.length;g++){
			out+=res[g]+"\t";
		}
		
		return out;
	}
	
	
	
	/**
	 * Returns the temperature array
	 * @return temperatures
	 */
	public double [] getTemperatures() {
		return Temperatures;
	}
	
	/**
	 * Sets the temperature array
	 * @param temperatures temperatures
	 */
	public void setTemperatures(double [] temperatures) {
		Temperatures = temperatures;
	}
	
	
	/**
	 * Sets the LmProbGenerator
	 * @param lmp LmProbGenerator
	 */
	public void setLmProbGenerator(LmProbGenerator lmp){
		this.lmp=lmp;
	}


	/**
	 * Returns the current temperature for this step
	 * @return temperature
	 */
	public double getCurrentTemp() {
		return CurrentTemp;
	}


	/**
	 * Sets the current temperature for this step
	 * @param currentTemp temperature
	 */
	public void setCurrentTemp(double currentTemp) {
		CurrentTemp = currentTemp;
	}

}
