/*
 * Created on Dec 15, 2005
 * 
 * by Nick Manoukis, Taylor Lab at EEB
 * manoukis@taylor0.biology.ucla.edu
 * 
 */
package gov.usda.ars.medfoes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Arrays;
import java.util.Random;

/**
 * Mainly static class with useful functions. Hopefully self explanatory
 * @author manoukis
 *
 */
public class Utilities
{
	
	private Random rand;
	
	
	public void Utilities(){
	this.rand = new Random();
	int id;
	
	}
	
	public void initSeed() {
//		Date d = new Date();
//		long epoch = d.getTime();
		if (rand == null)
		{
//		rand = new Random(epoch);
		rand = new Random();
		}

	}
	
	
	public void setSeed(long seed){
		if (rand == null)
		{
//		rand = new Random(epoch);
		rand = new Random();
		}
		rand.setSeed(seed);
	}
	
	
	public int nextInt() {
		return rand.nextInt();
	}
	
	public int nextInt(int i){
		return rand.nextInt(i);
	}
	
	public double nextDouble(){
		return rand.nextDouble();
	}
	
	/**
	 * get value at arbitrary pecentiles of a dataset
	 * @param data input data
	 * @param p percentile
	 * @return
	 */
	public static double getPercentile(double[]data,double p){
		 double[] sorted = new double[data.length];
	        System.arraycopy(data, 0, sorted, 0, data.length);
	        Arrays.sort(sorted);
	        double n = sorted.length;
	        double pos = p * (n + 1) / 100;
	        double fpos = Math.floor(pos);
	        int intPos = (int) fpos;
	        double dif = pos - fpos;

	        if (pos < 1) {
	            return sorted[0];
	        }
	        if (pos >= n) {
	            return sorted[sorted.length - 1];
	        }
	        double lower = sorted[intPos - 1];
	        double upper = sorted[intPos];
	        return lower + dif * (upper - lower);
	        
	}


	public static double[] getMeanAndSD(double[] values) {
		double total =0;
		double mean =0;
		for (int i =0; i<values.length;i++ )
		{
			//System.out.println("Error " + i + " " + values[i]);
			total += values[i];
		}
		mean = total/values.length;
		total =0;
		for (int i =0; i<values.length;i++ )
		{
			total += Math.pow((values[i]-mean),2);
		}
		double sem = (double)Math.sqrt((double)(total/(values.length -1)));
//		System.out.println("STDEV: "  + sem );
// below makes SEM instead of SD
//		sem = sem/(double)Math.sqrt(values.length);
		mean = round(mean,5);
		sem = round(sem,5);
		double res[] = {mean,sem};
		return res;
	}

		public static double round(double d, int i){
			return Math.round(d * Math.pow(10,i)) / Math.pow(10,i);
		}
		
		public  static FileWriter openFile(String name,boolean append) {
			FileWriter bw =null;
			try
			{
				bw = new FileWriter(name,append); 
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}
			return bw;

	}
	
		public static String makeFileSystemPath(String s, boolean appendTrailingSlash){
			s=s.replace("\\", "/");
			if (appendTrailingSlash==true){
				s=s+File.separator;
			}
			if (s.contains(" ")){
				System.err.println("File path "+s+" contains one or more space characters.\n Please make path without white space.");
				System.exit(-1);
			}
			//s="\""+s+"\"";
			//System.out.println(s);
			return s;
		}
		
		public static double [] getTempsFromFile(String fn, long skiplines) throws IOException{
			String filename = makeFileSystemPath(fn,false);
			
			// figure out how many lines in the temperature infile
			int lines=0;
			LineNumberReader  lnr = new LineNumberReader(new FileReader(new File(filename)));
			lnr.skip(Long.MAX_VALUE); // skip to maximum distance
			lines=lnr.getLineNumber();
			lnr.close();
			
			if( lines <= skiplines ){
				System.err.println("ERROR in Simulation::getTempsFromFile: Not enough lines ("+
								lines+") in file for requested skip ("+skiplines+")");
				System.exit(-1);				
			}
			lines -= skiplines;
			
			double[] temps=new double[lines-1];
			
			BufferedReader bufRdr  = new BufferedReader(new FileReader(filename));
			
		//	String [] line = null;
			// read in the header row, find out which column is air temp
			String [] header=bufRdr.readLine().split(",");
			int tempPos=0;
			int gotIt=0;
			
			for (int j=0;j<header.length;j++){
				if (header[j].equalsIgnoreCase("AT")){
					tempPos=j;
					gotIt++;
				}
				
			}
			
			//check if we found the header 'AT'
			if(gotIt==0){
				System.err.println ("ERROR in Simulation::getTempsFromFile: did not find a column labeled 'AT' for air temperatures \n please check " +
						"temperature infile");
				System.exit(-1);
			}
			

			// @TCC skipping lines (optionally)
			long curline_no = 0;
			while( curline_no < skiplines ){
				++curline_no;
				if( bufRdr.readLine() == null ){
					System.err.println("ERROR in Simulation::getTempsFromFile: Not enough lines in file for requested skip");
					System.exit(-1);
				}
			}
			
			//pull out the temperature column, feed to the variable T
			for (int i=1;i<lines;i++){
				String [] line=bufRdr.readLine().split(",");
				if (line[tempPos].equals("--")){ // missing data- need to generate with TemperatureEstimator.java
					System.err.println ("ERROR in Simulation::getTempsFromFile: There is missing data in line "+i+" \n Run TemperatureEstimator.java first.\n exiting...");
					System.exit(-1);
				}
				else{ // hourly data available. Proceed!
					try{
						temps[i-1]=Double.parseDouble(line[tempPos]);
					}
					catch (Exception e) {
						System.err.println ("ERROR in Simulation::getTempsFromFile: Error parsing double from csv file, line "+i);
						System.exit(-1);
					}
				}	
			}
			bufRdr.close();
			return temps;
		}
	

}
