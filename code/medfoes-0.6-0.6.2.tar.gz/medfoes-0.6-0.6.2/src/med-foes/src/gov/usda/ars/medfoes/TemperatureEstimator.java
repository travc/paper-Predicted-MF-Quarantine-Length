/**
 * Created 14 October 2011
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 */
package gov.usda.ars.medfoes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;

/**
 * Class to estimate hourly temperatures from daily min/max.
 * 
 * @author manoukis
 *
 */
public class TemperatureEstimator {
	
	public float [] Mins;
	public float [] Maxs;
	public int [] Jul;
	
	String infile;		// file with hourly data that has missing data to be filled in from averages. Expects CSV, with columns
						// labelled 'Jul', 'min' and 'max'. Will calculate hourly for all the days ('Jul') in the file, minus ends.
	String outfile;		// output file name
	
	
	/**
	 * A main for running TE. 
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
		TemperatureEstimator te = new TemperatureEstimator(args);
		
		
		
		
		String filename = te.infile;
		
		LineNumberReader  lnr = new LineNumberReader(new FileReader(new File(filename)));
		lnr.skip(Long.MAX_VALUE); // skip to maximum distance
		int lines=lnr.getLineNumber();
		
		te.Mins = new float [lines-1];
		te.Maxs = new float [lines-1];
		te.Jul = new int [lines-1];
		
		BufferedReader r  = new BufferedReader(new FileReader(filename));
		String [] header=r.readLine().split(",");
		
		if (header.length!=3){
			System.err.println("infile "+te.infile+" seems to contain a number of coulmns different than 3. Columns should be Jul,. min and max only");
			System.exit(-1);
		}
		
		

		// figure out order of columns
		
		int j=-1;int w=-1; int x=-1;
		for (int u=0;u<3;u++){
			if (header[u].trim().equalsIgnoreCase("Jul")){
				j=u;
			}
			if (header[u].trim().equalsIgnoreCase("Min")){
				w=u;
			}
			if (header[u].trim().equalsIgnoreCase("Max")){
				x=u;
			}
			
		}
		
		
		
		
		String line = null;
		
		
		int c = 0;
		while(c<lines-1){
			line = r.readLine();
			te.Jul[c] =Integer.parseInt(line.split(",")[j]);
			te.Mins[c]=Float.parseFloat(line.split(",")[w]);
			te.Maxs[c]=Float.parseFloat(line.split(",")[x]);
			c++;
		}
		
		r.close();
		
		
		
		 float[] result=te.CalculateHourly();
		 
		 // write the outfile
		 
		 try {
				BufferedWriter bws = new BufferedWriter(new FileWriter(te.outfile));
				bws.write("Jul,hour,temp\n");
				int y=-1;int h=0;
				for (int g=0;g<result.length;g++){
					if(g%24==0){
						y++;h=0;
					}
					bws.write(te.Jul[y]+","+h+","+result[g]+"\n");
					h++;
				}
				
				bws.close();
			} catch (IOException e) {
				System.err.println("ERROR in TemperatureEstimator::main creating file "+te.outfile+" as an output file");
				e.printStackTrace();
				System.exit(-1);
			}
			
			System.out.println("Program finished");
		 

	}
	
	

	private void loadparams(String [] args) {
		
		if (args.length!=4){
			System.out.print("Usage: TemperatureEstimator -i <infile> -o <outfile> \n read notes for more information\n");
			System.exit(0);
		}
		
		for (int i=0;i<args.length ;i++ ){
			if (args[i].equals("-i"))
			{this.infile = args[++i];
			System.out.println("Infile is "+this.infile);
			continue;}
			
			if (args[i].equals("-o"))
			{this.outfile = args[++i];
			System.out.println("Outfile is "+this.outfile);
			continue;}
			
			
		}
		
	}


	/**
	 * Constructor for running TE
	 * @param min array of minimum daily temperatures
	 * @param max array of maximum daily temperatures
	 */
	public TemperatureEstimator(float [] min, float [] max){
		if (min.length!=max.length){
			System.err.println("FATAL: TemperatureEstimator instantiated with min and max arrays of differing sizes");
			System.exit(-1);
		}
		int status=0;
		for (int i=0;i<min.length;i++){
			if (min[i]>max[i]){
				status++;
			}
			
		}
		if(status!=0){
			System.err.println("WARNING: TemperatureEstimator instantiated with min and max with bogus values: mins should be lower than max per day");
		}
		
		this.Mins=min;
		this.Maxs=max;
		
		CalculateHourly();
		
	}
	
	
	/**
	 * Main constructor- loads params from args
	 * @param args the infile
	 */
	public TemperatureEstimator(String[] args) {
		loadparams(args);
	}



	/**
	 * Calculate hourly estimated temperatures from an array of min and and array of max values set in this class
	 * Uses the method described on pg. 29 of Campbell and Norman (1998) "An Introduction to Environmental Biophysics" 
	 * @return hourly temps
	 */
	
	public float[] CalculateHourly(){
		
		float [] out = new float[Mins.length*24];
		float [] start = TriangulateOne(Mins[0],Maxs[0]);
		float [] end = TriangulateOne(Mins[Mins.length-1],Maxs[Maxs.length-1]);
		
		//populate first day's data with simple triangulation- there is probably a faster way to do this.
		for (int j=0;j<24;j++){
			out[j]=start[j];
			out[out.length-j-1]=end[j]; // THIS is backwards. TODO: fix it, perhaps
		}
		
		
		double [] gamma = new double[24];
		double omega=Math.PI/12;
		for (int i=0;i<24;i++){
			gamma[i]=0.44-( 0.46*Math.sin((omega*i)+0.9) )+( 0.11*Math.sin((2*omega*i)+0.9) );
			
			//gamma[i]=0.44-(0.46*Math.sin(((Math.PI*i)/12)+0.9))+(0.11*Math.sin((2*Math.PI/12)+0.9));
		}
		
		
		int gpos = 0; // position in the pre-calculated gamma array, also hour of the day (0-23)
		int c=0; // current day (position in Mins and Maxs arrays)
		// here do the real work
		
		for (int i=24;i<out.length-23;i++){
			if (i%24==0){
				gpos = 0;
				c++;
			}
			if(gpos<=5){ // use first equation
				out[i]=(float) ((Mins[c-1]*gamma[gpos])+(Maxs[c]*(1-gamma[gpos])));
			}
			else if (gpos<=14){ // use second equation
				out[i]=(float) ((Mins[c]*gamma[gpos])+(Maxs[c]*(1-gamma[gpos])));
			}
			else{ // use third equation
				out[i]=(float) ((Mins[c]*gamma[gpos])+(Maxs[c+1]*(1-gamma[gpos])));
			}
			gpos++;
			// check if we need to reset the gamma array counter to position 0 (at start of each day)
			//if (hour%24==0){
			//	gpos=0;
			//}
			
		}
		
		return out;
		
	}
	
	
	/**
	 * Use simple triangulation to calculate hourly temperatures from a min and max for a single day
	 * This method is used internally to get hourly temps for the first and last days of the range 
	 * returned by CalculateHourly
	 * @param min minimum temperature for the day
	 * @param max maximum temperature for the day
	 * @return
	 */
	private float [] TriangulateOne (float min, float max){
		if (min>max){
			System.err.println("WARNING: TemperatureEstimator::TriangulateOne got bogus min and max values!");
		}
		float [] out=new float [24];
		float diff=(max-min)/12;
		
		out[0]=min;
		
		for (int i=1;i<13;i++){
			out[i]=out[i-1]+diff;
		}
		
		for (int i=13;i<24;i++){
			out[i]=out[i-1]-diff;
		}
		return (out);
		
	}
	
	
	
	

}
