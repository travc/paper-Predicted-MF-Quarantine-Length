/**
 * Created 23 Oct 2013
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 */
package gov.usda.ars.medfoesp;

import java.io.IOException;
//import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
//import java.util.List;
import java.util.ListIterator;

import com.xeiam.xchart.BitmapEncoder;
import com.xeiam.xchart.Chart;
import com.xeiam.xchart.ChartBuilder;
import com.xeiam.xchart.Series;
import com.xeiam.xchart.SeriesLineStyle;
import com.xeiam.xchart.StyleManager.ChartTheme;
import com.xeiam.xchart.StyleManager.ChartType;
import com.xeiam.xchart.StyleManager.LegendPosition;
import com.xeiam.xchart.SwingWrapper;

/**
 * Plots results from multiple simulations.
 * 
 * @author manoukis
 *
 */
public class Plotter {
	ResultHolder r;
	
	public Plotter(ResultHolder r){
		this.r=r;
		
	}
	
	
	/**
	 * Generate the figures that summarize important data across simulations
	 * @param outDir Directory in which to put figures
	 * @param timeStamp unique identifier
	 * @throws IOException IO error
	 */
	public void generateFigures(String outDir,String timeStamp) throws IOException{
	//	double [] minmax=getMinMax(r.getTimes());
	//	double[]timeFreqs = calcHistogram(r.getTimes(),minmax[0]-1,minmax[1]+1,10);
	//	double [] midValues = calcMidValues(r.getTimes(),minmax[0],minmax[1],10);
		
		double [] minmaxN=getMinMax(r.getNumbers());
		double[]timeFreqsN = calcHistogram(r.getNumbers(),minmaxN[0]-1,minmaxN[1]+1,10);
		double [] midValuesN = calcMidValues(r.getNumbers(),minmaxN[0],minmaxN[1],10);
		
		double [][] ecdf = getEmpiricalCumFreqDist(r.getTimes());
		
		
		
		// Create Time frequency distribution

//		Chart timeChart = new ChartBuilder().chartType(ChartType.Bar).width(800).height(600).title("Number of Days Simulated").xAxisTitle("Time in Days (bin mid point)").yAxisTitle("Number").build();
//		 timeChart.addSeries("times", midValues, timeFreqs);
//		 timeChart.getStyleManager().setLegendPosition(LegendPosition.InsideNW);
		
		// Create Time ECDF
		 Chart timeChart = new ChartBuilder().width(800).height(600).theme(ChartTheme.Matlab).title("ECDF of Times").xAxisTitle("Time (days)").yAxisTitle("Prop. Simulations Extirpated").build();
		 timeChart.getStyleManager().setPlotGridLinesVisible(false);
	//	 timeChart.getStyleManager().setXAxisTickMarkSpacingHint(100);
		 
		Series series1 = timeChart.addSeries("ecdf", ecdf[0], ecdf[1]);
		series1.setLineStyle(SeriesLineStyle.DOT_DOT);
		 
		// Create Numbers frequency distribution
		 Chart numbersChart = new ChartBuilder().chartType(ChartType.Bar).width(800).height(600).theme(ChartTheme.Matlab).title("Number of Flies Remaining at End of Simulations").xAxisTitle("Number of flies (bin mid point)").yAxisTitle("Number").build();
		 numbersChart.addSeries("numbers", midValuesN, timeFreqsN);
		 numbersChart.getStyleManager().setLegendPosition(LegendPosition.InsideNW);
		 

			


		LinkedList<Chart> charts=new LinkedList<Chart>();
		charts.add(timeChart);
		charts.add(numbersChart);

			 BitmapEncoder.savePNG(timeChart, outDir+"time_ecdf_"+timeStamp+".png");
			 BitmapEncoder.savePNG(numbersChart, outDir+"numbers_histogram_"+timeStamp+".png");
		 if (r.showPlot==true){
			 new SwingWrapper(charts).displayChartMatrix();
		 }
		
	}
	
	private double [] getMinMax(double [] in){
		double [] out = new double [2];
		out[0]=Double.MAX_VALUE;
		out[1]=Double.MIN_VALUE;
		for (int i=0;i<in.length;i++){
			if (in[i]<out[0]){
				out[0]=in[i];
			}
			if (in[i]>out[1]){
				out[1]=in[i];
			}
		}
		return out;
	}
	
	private double [][] getEmpiricalCumFreqDist(double[]in){
		Arrays.sort(in); //sort data so we know min/max
		//Frequency f= new Frequency();
		//for (double i : in){
		//	f.addValue(Math.round(i));
		//}
		double [] times=new double[100];
		double interval=(in[in.length-1]-in[0])/99;
		for (int i=0;i<100;i++){
			times[i]=in[0]+(i*interval);
		}
		double [] freqs = new double[100];
		int j=0;double n=0;
		for (int y = 0; y<99;y++){
			while(in[j]<=times[y]){
				n++;
				j++;
			}
			freqs[y]=n/in.length;
			j=0;n=0;
//			freqs [y]=f.getCumPct((long)times[y]);
		}
		freqs[freqs.length-1]=1; // necessary?
		double[][]out = new double[2][];
		out[0]=times;out[1]=freqs;
		return out;
		
//		double[][]out=new double[2][100];
//		Arrays.sort(in);
//		double max = in[in.length-1];
//		double min = in[0];
//		double current=min; double count=1;
//		double div = (max-min)/100;double n=1;
//		for (int i=0;i<100;i++){
//			for (int j=0;j<in.length;j++){
//				if (in[j]<=current+(i*div)){
//					count++;
//				}
//				else{
//					break;
//				}
//			}
//			if(in[i]<=current+(n*div)){
//				count++;
//			}
//			else{
//				out[0][i]=current+(n*div);
//				out[1][i]=count;
//				count++;
//				n++;
//			}
//			
//		}
		
	}
	
	/**
	 * Modified based on function of user Max, with assist from user1172468; 
	 * see http://stackoverflow.com/questions/10786465/how-to-generate-bins-for-histogram-using-apache-math-3-0-in-java
	 * @param data
	 * @param min
	 * @param max
	 * @param numBins
	 * @return
	 */
	private static double[] calcHistogram(double[] data, double min, double max, int numBins) {
		  final double[] result = new double[numBins];
		  final double binSize = (max - min)/numBins;

		  for (double d : data) {
		    int bin = (int) ((d - min) / binSize); // changed this from numBins
		    if (bin < 0) { /* this data is smaller than min */ }
		    else if (bin >= numBins) { /* this data point is bigger than max */ }
		    else {
		      result[bin] += 1;
		    }
		  }
		  return result;
		}
	
	private static double[] calcMidValues(double[]data,double min, double max,int numBins){
		 final double[] result = new double[numBins];
		 final double binSize = (max - min)/numBins;
		 
		 for (int u=0;u<result.length;u++){
			 result[u]=(int) (min+(u*binSize)+(0.5*binSize));
		 }
		 return result;
		
	}
	
	
	
	private double [] [] binIt (LinkedList in){
		double[]  [] out = new double [2][]; // first element= bins, second = frequency.
		double min = 1000;
		double max = 0;
		
		ListIterator i = in.listIterator();
		
		// get min and max
		while (i.hasNext()){
			double n= (Double) i.next();
			if (min>n){
				min=n;
			}
			if (max<n){
				max=n;
			}
		}
		double binsize = (double)Math.round((max-min)/10);
		// now tally the whole thing. This is slow.
		double [] bins = new double [(int) ((max-min)/binsize)];
		double [] freqs = new double [(int) ((max-min)/binsize)];
		int count = 0;
		for (int j=0;j<bins.length;j++){
			bins[j]=min+(count*binsize);
			int fre = 0;
			for (int x=0;x<in.size();x++){
//				if (bins[j]>min){
//					if(in.get(x)>bins[j-1]||in.get(x)<bins[j]){
//						fre++;
//					}
//				}
//				else{
//					if (in.get(x)<min+binsize){//we are working on the first bin.
//						fre++;
//					}
//				}
				
			}
			freqs[j]=fre;
			count++;
		}
		out[0]=bins;out[1]=freqs;
		
		return out;
	}
	


}
