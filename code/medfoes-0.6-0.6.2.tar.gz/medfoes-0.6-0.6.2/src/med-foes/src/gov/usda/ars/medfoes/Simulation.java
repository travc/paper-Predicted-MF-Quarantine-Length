/**
 * Created 8 July 2011
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 * 
 */
package gov.usda.ars.medfoes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import com.reallymany.trapgrid.*;

/**
 * Main simulation class for MED-FOES
 * 
 * This class reads in & stores parameters and also includes the probability generators for all the events that
 * occur each tick.
 * 
 * @author manoukis
 *
 */
/**
 * @author manoukis
 *
 */
public class Simulation {
	
	// Parameters needed to run a simulation are seen below
	// tick = 1 hr. This resolution for weather data is needed, directly or by interpolation.
	// note that developmental parameters, survival are PER DAY. This is converted in the model
	
	// Below are input parameters
	int Ni;			// number of adult females at start of simulation
	double Me;		// estimated daily mortality of eggs
	double Ma;		// estimated daily mortality of adults
	double Ml;		// estimated daily mortality of larvae
	double Mp;		// estimated daily mortality of pupae
	double [] TEL;		// Tmin [0] and K [1] for transition from egg to larvae (hatching rate/day)
	double [] TLP;		// Tmin [0] and K [1] for transition from larvae to pupae (pupation rate/day)
	double [] TPA;		// Tmin [0] and K [1] for transition from pupae to adult (emergence rate/day)
	double [] TIM;		// Tmin [0] and K [1] for transition from immature to mature adult (ovarian maturation rate/day)
	int r;			// number of eggs produced by female per reproduction
	float rvar;		// variance in the number of eggs produced per female per reproduction
	double rred;	// proportion of population that loses the ability to reproduce per day after R. required.
	double S;		// eradication pressure from countermeasures on adults (rate- proportion all adults killed per day)
	double R;		// time from first find to start of quarantine (start of eradication pressure)
	int MaxFlies;	// maximum number of flies allowed to be alive before simulation exits (optional)
	int DevModel; 	// how to progress through development: 0=uniform sampling 1=thermal unit accumulation
	boolean SterileAfterIntervention;	// whether flies produced after the intervention are all sterile. 
	double Tmax;	// maximum temperature at which development can occur
	double TuSD;	// Standard deviation about the mean thermal units needed for stage transition *as a proportion of mean*
	double [] StableDist; 	// percent individuals in each of 5 classes of stable age distribution. Default is Carey 1982.
	boolean tempDepMortality; // whether mortality is temperature dependet or fixed daily rate. Optional, default=fixed daily rate
	long seed;
	
	// These are variables to track or for output.
//	float F;		// index of the availability of host fruit in the area- will affect Sx, r
	double [] T;		// Hourly Temperatures. Length = maximum simulation run time
	int hours;		// number of hours passed since first find (outbreak)
	private Population p;	// the population being simulated
	
	//Spatial parameters (ALL TRAPGRID MARKED WITH @TG)
	boolean tgTrue; 		// Whether we are simulating traps at all
	String tgFile;			// TrapGrid file
	int tgIter;				// Number of trapgrid simulations to run
	int tgLimit;			// number of days to simulate trapping
	double tgD;				// Diffusion coefficient for TrapGrid
	double [] tgEscapeProb;//  daily probability of escaping the trapgrid

	//	boolean WriteOutputBool; // whether to have outfiles or put output on console; true=write to file
	String o;				// if not null, output to this file basename.
	boolean Silent;			// whether to be chatty on the console; if true, only results are shown on console or written to files after run
//	String Od;		// filename for detailed output
//	String Os;		// filename for summary output
	String Tfile;	// filename where temps are
	long Tfile_skiplines = 0; // how many lines (temperatures) in Tfile to skip
	
	boolean shared_params_set = false; // Flag saying if some params are already set by medfoesp
	
	// objects for holding results (for each day)
	private int [] times; // holding days
	private double[] [] temps; // mean, min and max for each simulated day.
	private int [] [] demography; // # eggs, # larvae, # pupae and # adults per simulated day.
	private int [] []cumulativeBirthsDeaths; // cumulative number of births and deaths per simulated day
	
	//finally, some other info
	String version;
	boolean ParallelMode;
	Utilities u;
	int end_condition_code = -1; // Set by exitSimulation
	
	public static enum EndCondition{
		EXTIRPATION,
		OUT_OF_TEMPERTURES,
		TOO_MANY_FILES,
		UNKNOWN
	}
	
	/**
	 * default method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Simulation s = new Simulation();
		s.version="0.6";
		s.run(args);
	}

	
	/**
	 * Set parameters instansiated by MedfoesP/Tasker
	 * Those parameters must be accessed read-only!
	 * 
	 * @param T hourly temperatures
	 */
	public void setSharedParams(double [] T) {
		this.shared_params_set = true;
		this.T = T;
	}
	
	
	/**
	 * Run the simulation. Program will run until it runs out of temperatures or there are no more living flies
	 * @param args The parameters for this instance of simulation
	 * @return model outputs
	 */
	public String [] run (String [] args) {
		if (args.length <2) {
			if (args[0].equalsIgnoreCase("-v")){
				System.out.println("MED-FOES version "+version);
				System.exit(0);
			}
			
			System.err.println("Usage:  java med-foes.jar -f paramfileName [-parameter value ..]");
			System.exit(-1);
		}
		
		try {
			loadSimulationParameters(args);
		} 
		catch (IOException e) {
			System.err.println("problem with infile");
			e.printStackTrace();
			System.exit(-1);
		}
		if (Silent == false){
			System.out.print("Loading simulation parameters ...");
			System.out.print("DONE\n");
		}

		// set seed, if applicable
		u=new Utilities();
		if (this.seed==0){
			Date d = new Date();
			seed = d.getTime();
			u.setSeed(seed);
		}
		else{
			u.setSeed(seed);
		}

		
		LmProbGenerator lmp=new LmProbGenerator (u);
		p = new Population(this,lmp,T);
		
		try{
			p.InitializePopulation(Ni, StableDist);
		}
		catch (Exception e){ // if there is no StableDist
			p.InitializePopulation(Ni);
		}
		
		if (Silent == false){
			System.out.println("Starting simulation ... ");
		}
		
		// initialize result holders before running
		try{
			times = new int [(T.length/24)+1];
			temps = new double [(T.length/24)+1][3]; // mean, min and max for each simulated day.
			demography = new int [(T.length/24)+1][4]; // # eggs, # larvae, # pupae and # adults per simulated day.
			cumulativeBirthsDeaths = new int [(T.length/24)+1][2]; // cumulative number of births and deaths per simulated day
		}
		catch (Exception e){
			System.out.println("ERROR in Simulation::run. \n Failed to initialize output variables based on temperature profile. \n check" +
					"that you have set -T");
			e.printStackTrace();
			System.exit(-1);
		}
		
		// @TG calculate the daily escape probability, if spatial is included.
		if (tgTrue==true){
			if (Silent==false){
				System.out.println("Running spatial trapping simulations...");
			}
			TrapGridRunner tgr = new TrapGridRunner();
			
			tgr.setParameters(tgFile, tgIter,tgLimit,tgD, p);
			double [] tgFirstPass=tgr.run(); // calculate tg escape probs until tglimit
			
			// We also need the mean value- fill the rest of array with this, for trapping
			//beyond tglimit
			
			double tgmean=0;
			double [] tgSecondPass=new double[T.length/24];
			for (int i = 0; i<T.length/24; i++){
				if (i<tgLimit){
					tgmean+=tgFirstPass[i];
					tgSecondPass[i]=tgFirstPass[i];
				}
				else if (i==tgLimit){
					tgmean=tgmean/tgFirstPass.length;
					tgSecondPass[i]=tgmean;
				}
				else{
					tgSecondPass[i]=tgmean;
				}
			}
			setTgEscapeProb(tgSecondPass);

			if (Silent==false){
				System.out.println("DONE");
			}
		}
		// @TG END spatial calculation	

		// the actual run loop is below
		hours = 0;  // Starting at 0, of course
		while( true ){		
			// each day, collect data on the run and add it to arrays.
			if (hours%24==0){
				int y=hours/24;
				times[y]=y;
				for (int b=0;b<4;b++){
					demography[y][b]=p.getNumberByStage(b);
				}
				cumulativeBirthsDeaths[y][0]=p.deadFlies;
				cumulativeBirthsDeaths[y][1]=p.eggsLaid;
				if (hours>=24){ // calculate temp stats for **previous day**
					double [] yesterdaysTemps=new double[24];
					double mymin=0; double mymax=0;
					for (int a=0; a<24; a++){
						if (a==0){mymin=T[hours-1-a];mymax=T[hours-1-a];}
						else{
							if (T[hours-1-a]<mymin){mymin=T[hours-1-a];}
							if (T[hours-1-a]>mymax){mymax=T[hours-1-a];}
						}
						yesterdaysTemps[a]=T[hours-1-a];
					}
					temps[y][0]=Utilities.getMeanAndSD(yesterdaysTemps)[0];
					temps[y][1]=mymin;
					temps[y][2]=mymax;
				}
				
			}

			// Are we done, or do we need to keep going...
			// check if we have exceeded max number of flies
			if (p.getNumberOfFlies()>MaxFlies){
				// End condition: Too many flies error
				exitSimulation(EndCondition.TOO_MANY_FILES);
				break;
			}
			// if the number of flies reaches zero, stop the simulation
			if (p.getNumberOfFlies()==0){
				// End condition: Extirpation
				exitSimulation(EndCondition.EXTIRPATION);
				break;
			}
			// End condition: Ran out of temperatures
			if (hours >= T.length){
				exitSimulation(EndCondition.OUT_OF_TEMPERTURES);
				break;
			}
			
			// else... keep going
			if (hours%240==0&& Silent == false){
				System.out.println("Simulating day\t"+hours/24);
			}
			// step, increment hours
			assert hours < T.length;
			p.step();
			hours++;
		}
		
		//exitSimulation();
		
		// these lines should never be reached, unless in parallel mode
		if (ParallelMode==false){
			System.out.print("ERROR in Simulation: exitSimulation has not been called");

		}
		String [] out =new String [1];
		return out;
	}

	/**
	 * Final steps before exiting simulation: write output files or echo results to console, then exit system. May be called 
	 * when the simulation runs out of hourly temperatures or when the last fly dies.
	 */
	public void exitSimulation(EndCondition end_condition) {
		String[]out_r=outputDetails(hours/24);
		String summary = outputSummary();

		switch( end_condition ){
			case EXTIRPATION:
				System.out.println("Extripation @ hour "+hours);
				end_condition_code = 0;
				break;
			case OUT_OF_TEMPERTURES:
				System.out.println("WARNING: OUT OF TEMPERATURES @ hour "+hours);
				end_condition_code = 1;
				break;
			case TOO_MANY_FILES:
				System.out.println("WARNING: TOO MANY FLIES @ hour "+hours);
				end_condition_code = 2;
				break;
			case UNKNOWN:
				end_condition_code = 3;
				System.out.println("ERROR: Exit without a valid end condition");
		}	
		
		if(Silent==false){
		System.out.println("Simulation completed successfully\n");
			if (o==null==false){
				System.out.print("Writing output files ... ");
				// write to files
				try {
					BufferedWriter bws = new BufferedWriter(new FileWriter(o+"_summary.txt"));
					bws.write(summary);
					bws.close();
				} catch (IOException e) {
					System.err.println("ERROR in Simulation::exitSimulation: failed to create file "+o+"_summary.txt"+" as summary output file");
					e.printStackTrace();
					System.exit(-1);
				}
				try {
					BufferedWriter bwd = new BufferedWriter(new FileWriter(o+"_detail.txt"));
					for (int j=0;j<out_r.length;j++){
						bwd.write(out_r[j]+"\n");
					}
					bwd.close();
					
				} catch (IOException e) {
					System.err.println("ERROR in Simulation::exitSimulation: failed to create file "+o+"_detail.txt"+" as detailed output file");
					e.printStackTrace();
					System.exit(-1);
				}
				
				System.out.print("DONE\n");
			}
			else{
				// output to console- details first, then summary
				for (int h=0;h<out_r.length;h++){
					System.out.println(out_r[h]);
				}
				System.out.println(summary);
			}
		}
		else{ //silent == true
			if (this.o==null==false){
				// write to files
				try {
					BufferedWriter bws = new BufferedWriter(new FileWriter(o+"_summary.txt"));
					bws.write(summary);
					bws.close();
				} catch (IOException e) {
					System.err.println("ERROR in Simulation::exitSimulation: failed to create file "+o+"_summary.txt"+" as deailed output file");
					e.printStackTrace();
					System.exit(-1);
				}
				try {
					BufferedWriter bwd = new BufferedWriter(new FileWriter(o+"_detail.txt"));
					for (int j=0;j<out_r.length;j++){
						bwd.write(out_r[j]+"\n");
					}
					bwd.close();
					
				} catch (IOException e) {
					System.err.println("ERROR in Simulation::exitSimulation: failed to create file "+o+"_detail.txt"+" as deailed output file");
					e.printStackTrace();
					System.exit(-1);
				}
				
			}
			else{
				// output to console- details first, then summary
				for (int h=0;h<out_r.length;h++){
					System.out.println(out_r[h]);
				}
				System.out.println(summary);
			}
			
			
		}

		if (ParallelMode==false){
			System.exit(0);
		}
		
	}
	
	/**
	 * Output summary information for the simulation
	 * @return Summary info
	 */
	public String outputSummary(){
		String out = "";
		out+="MED-FOES version "+version+" summary\n";
		out+="---------------------------------\n";
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		
		out+="\nGENERAL\n";
		out+="Run completed on: "+dateFormat.format(date)+"\n";
		if(this.o==null==false){
			out+="This file name: "+o+"_summary.txt"+"\n";
			out+="Detailed output file name: "+o+"_detail.txt"+"\n";
		}
		out+="Maximum number of flies permitted: "+MaxFlies+"\n";
		out+="seed used: "+seed+"\n";
		
		out+="\nRESULTS\n";
		out+="Number of hourly temps read: "+T.length+"\n";
		out+="Number of hours simulated: "+hours+"\n";
		out+="Number of Flies at end of simulation: "+p.getNumberOfFlies()+"\n";
		out+="Cumulative number of eggs: "+p.eggsLaid+"\n";
		out+="Cumulative number of deaths: "+p.deadFlies+"\n";
		//out+="Cumulative number of eggs: "+cumulativeBirthsDeaths[(hours/24)-1][0]+"\n";
		//out+="Cumulative number of deaths: "+cumulativeBirthsDeaths[(hours/24)-1][1]+"\n";
		
		out+="\nPARAMETERS\n";
		out+=" Ni: "+Ni+"\n R: "+R+"\n S: "+S+
		"\n TEL: "+TEL[0]+","+TEL[1]+"\n TLP: "+TLP[0]+","+TLP[1]+"\n TPA: "+TPA[0]+","+TPA[1]+"\n TIM: "+TIM[0]+","+TIM[1]+
		"\n Me: "+Me+"\n Ml: "+Ml+"\n Mp: "+Mp+"\n Ma: "+Ma+
		"\n r: "+r+"\n rvar: "+rvar+"\n rred: "+rred+"\n Tmax: "+Tmax+
		"\n Dm: "+DevModel+"\n Sai: "+SterileAfterIntervention+"\n tdm: "+tempDepMortality+"\n TuSD: "+TuSD
		+"\n T: "+Tfile;
		try {
			out+="\n Initial Age distribution: ";
			for (int k=0;k<StableDist.length;k++){
				out+=StableDist[k]+"\t";
			}
		}
		catch (Exception e){
			out+="Program default";
		}
		if (tgTrue==true){
			out+="\n tg: true";
			out+="\n tgf: "+tgFile+"\n tgl: "+tgLimit+"\n tgd: "+tgD;
		}
		else{
			out+="\n No spatial component";
		}
		
		return out;
	}
	
	/**
	 * Get summary run information from this Simulation- for Medfoesp. 
	 * 
	 * @return number or hours sim ran, number of flies at end, ending condition code
	 */
	public double [] outputSummaryForMedfoesp(){
//		double [] times;	//number of hours simulated **run time**	
//		double [] numbers;	//numbers at end of sims
//		int [] end_conditions; // end condition code for each run (0=Extirpation, 1=Out of temps, 2=Too many flies)

		double [] out = new double [4];
		out[0] = hours; // number of hours the simulation ran	
		out[1] = p.getNumberOfFlies(); //number of flies at the end of the simulation
		out[2] = end_condition_code;
		return out;
	}
	
	/**
	 * Output detailed information for the simulation (time series)
	 * @return daily information
	 */
	public String [] outputDetails(int length){
		String [] out = new String [length+1];
		out[0]="time,mean_temp,min_temp,max_temp,cum_death,cum_birth,stage0,stage1,stage2,stage3,total";
		for (int u=0;u<hours/24;u++){
			int sum=0;
			for (int j=0;j<4;j++){
				sum+=demography[u][j];
			}
			out[u+1]=times[u]+","+temps[u][0]+","+temps[u][1]+","+temps[u][2]+","+cumulativeBirthsDeaths[u][0]+","+cumulativeBirthsDeaths[u][1]+","+demography[u][0]+","+demography[u][1]+","+demography[u][2]
			   +","+demography[u][3]+","+sum;
		}
		
		return out;
	}


	/**
	 * This method reads in parameters, either from a file or from the command line or 
	 * both. Note that command line parameters over ride those in any infile. Also, 
	 * command line does NOT take size and migration arrays. It takes a min, max and 
	 * step number and the array is generated internally.
	 * @param args The param file name or run time parameters.
	 * @throws IOException
	 */	
		public void loadSimulationParameters(String [] args) throws IOException {
			int params = 0;
			boolean file = false;
			String inputFile="";
			String tmp;

			for (int i=0;i<args.length ;i++ ) {
				if (args[i].equals("-f")) {
					file = true;
					inputFile = args[i+1];
					break;
				}
			}

			if (file==true){
				FileInputStream is = new FileInputStream(inputFile);
				try {
					Properties p = new Properties();
					p.load(is);
					params += p.size(); //this is bad.
					this.Ni = Integer.parseInt( p.getProperty("Ni"));
					/** example of reading in array

					String [] t2 = p.getProperty("s1").split(",");
					this.sizesP1 = new int [t2.length];
					for (int u=0;u<t2.length;u++){
						this.sizesP1[u]=Integer.parseInt(t2[u]);
					}
					 */
					
					this.rred = Double.parseDouble(p.getProperty("rred"));
					this.tempDepMortality = Boolean.parseBoolean(p.getProperty("tdm"));
					
					
					this.Ma = Double.parseDouble(p.getProperty("Ma"));
					this.Me = Double.parseDouble(p.getProperty("Me"));
					this.Ml = Double.parseDouble(p.getProperty("Ml"));
					this.Mp = Double.parseDouble(p.getProperty("Mp"));

					this.TEL=new double[2];
					this.TLP=new double[2];
					this.TPA=new double[2];
					this.TIM=new double[2];
					
					this.TEL[0] = Double.parseDouble(p.getProperty("TEL").split(",")[0]);
					this.TEL[1] = Double.parseDouble(p.getProperty("TEL").split(",")[1]);
					this.TLP[0] = Double.parseDouble(p.getProperty("TLP").split(",")[0]);
					this.TLP[1] = Double.parseDouble(p.getProperty("TLP").split(",")[1]);
					this.TPA[0] = Double.parseDouble(p.getProperty("TPA").split(",")[0]);
					this.TPA[1] = Double.parseDouble(p.getProperty("TPA").split(",")[1]);
					this.TIM[0] = Double.parseDouble(p.getProperty("TIM").split(",")[0]);
					this.TIM[1] = Double.parseDouble(p.getProperty("TIM").split(",")[1]);
					
					
					this.r = Integer.parseInt(p.getProperty("r"));
					this.rvar = Float.parseFloat(p.getProperty("rvar"));
					this.R = Double.parseDouble(p.getProperty("R"));
					this.MaxFlies = Integer.parseInt(p.getProperty("Mx"));
					
					if (p.containsKey("Ad")){
						String [] j = p.getProperty("Ad").split(",");
						this.StableDist=new double[5];
						for (int y=0;y<5;y++){
							this.StableDist[y]=Double.parseDouble(j[y]);
						}
					}
					
					if (p.containsKey("Sai")){
						this.SterileAfterIntervention=Boolean.parseBoolean(p.getProperty("Sai"));
					}
					
					if (p.containsKey("Dm")){
						this.DevModel = Integer.parseInt(p.getProperty("Dm"));
						this.TuSD = Double.parseDouble(p.getProperty("TuSD"));
					}
					else{
						this.DevModel=0;
					}
					
					this.Tmax = Double.parseDouble(p.getProperty("Tmax"));
					
					if (p.containsKey("seed")){
						this.seed = Long.parseLong(p.getProperty("seed"));
					}
					
					
					this.S = Double.parseDouble(p.getProperty("S"));
					
					this.Tfile = p.getProperty("T");
					tmp = p.getProperty("Tskip");
					this.Tfile_skiplines = tmp == null ? 0 : Long.parseLong(tmp);
					this.T = Utilities.getTempsFromFile(Tfile, Tfile_skiplines);
					if (p.containsKey("o")){
						this.o = Utilities.makeFileSystemPath(p.getProperty("o"),false);
					}
					else{
						this.o=null;
					}
					
					//@TG load spatial parameters from a FILE!
					if (p.containsKey("tg")){
						this.tgTrue=Boolean.parseBoolean(p.getProperty("tg"));
					}
					
					
					if (this.tgTrue==true){
						//Make sure we have all required spatial parameters
						int err=0;
						if (p.containsKey("tgf")==false){
							System.err.println("Parameter Error: Spatial option (tg=true) requires tgf");
							err++;
						}
						if (p.containsKey("tgi")==false){
							System.err.println("Parameter Error: Spatial option (tg=true) requires tgi");
							err++;
						}
						if (p.containsKey("tgl")==false){
							System.err.println("Parameter Error: Spatial option (tg=true) requires tgl");
							err++;
						}
						if (p.containsKey("tgd")==false){
							System.err.println("Parameter Error: Spatial option (tg=true) requires tgd");
							err++;
						}
						if (err>0){
							System.err.println(err+" spatial parameter values needed..exiting");
							System.exit(-1);
						}
						
						this.tgFile = Utilities.makeFileSystemPath(p.getProperty("tgf"),false);
						this.tgIter = Integer.parseInt(p.getProperty("tgi"));
						this.tgLimit = Integer.parseInt(p.getProperty("tgl"));
						this.tgD = Double.parseDouble(p.getProperty("tgd"));
					}
					//@TG end spatial parameter reading from file.
					
//					this.Os = p.getProperty("Os");
//					this.Od = p.getProperty("Od");
//					this.WriteOutputBool = Boolean.parseBoolean(p.getProperty ("o"));
					this.Silent = Boolean.parseBoolean(p.getProperty("q"));
					
				}
				catch (FileNotFoundException ex)
				{
					System.out.println("ERROR in Simulation::loadSimulationParameters: could not load infile: " + inputFile);
					ex.printStackTrace();
					System.exit(1);
				}
				}

			//This section reads the paramters sent in the command line and overrides the parameters in the parameters file
			
			for (int i=0;i<args.length ;i++ )
			{
				/**
				 * Again, sample for doing an array.
				
				if (args[i].equalsIgnoreCase("-s0"))
					{String [] t = args[++i].split(",");
					this.sizesP0 = new int [t.length];
					for (int u=0;u<t.length;u++){
						this.sizesP0[u]=Integer.parseInt(t[u]);
						}
					params++;
					continue;}
					
				 */
				
				
				if (args[i].equals("-Ni"))
					{this.Ni = (int)Math.round(Double.parseDouble(args[++i]));
					params++;
					continue;}
				//if (args[i].equals("-Ni"))
				//	{this.Ni = Integer.parseInt(args[++i]);
				//	params++;

				if (args[i].equals("-Ma"))
					{this.Ma = Double.parseDouble(args[++i]);
					params++;
					continue;}
				if (args[i].equalsIgnoreCase("-Me"))
					{this.Me = Double.parseDouble(args[++i]);
					params++;
					continue;}
					if (args[i].equals("-Ml"))
					{this.Ml = Double.parseDouble(args[++i]);
					params++;
					continue;}
					if (args[i].equals("-Mp"))
					{this.Mp = Double.parseDouble(args[++i]);
					params++;
					continue;}
					
					if (args[i].equals("-tdm"))
					{this.tempDepMortality = Boolean.parseBoolean(args[++i]);
					params++;
					continue;}
					
					if (args[i].equals("-rred"))
					{this.rred = Double.parseDouble(args[++i]);
					params++;
					continue;}

				if (args[i].equals("-TEL"))
					{String [] t = args[++i].split(",");
					this.TEL = new double [t.length];
					this.TEL[0] = Double.parseDouble(t[0]);
					this.TEL[1] = Double.parseDouble(t[1]);
					params++;
					continue;}
				if (args[i].equals("-TLP"))
					{String [] t = args[++i].split(",");
					this.TLP = new double [t.length];
					this.TLP[0] = Double.parseDouble(t[0]);
					this.TLP[1] = Double.parseDouble(t[1]);
					params++;
					continue;}
				if (args[i].equals("-TPA"))
					{String [] t = args[++i].split(",");
					this.TPA = new double [t.length];
					this.TPA[0] = Double.parseDouble(t[0]);
					this.TPA[1] = Double.parseDouble(t[1]);
					params++;
					continue;}
				if (args[i].equals("-TIM"))
					{String [] t = args[++i].split(",");
					this.TIM = new double [t.length];
					this.TIM[0] = Double.parseDouble(t[0]);
					this.TIM[1] = Double.parseDouble(t[1]);
					params++;
					continue;}
				
				if (args[i].equals("-Ad"))
					{String [] t = args[++i].split(",");
					this.StableDist = new double [t.length];
					this.StableDist[0] = Double.parseDouble(t[0]);
					this.StableDist[1] = Double.parseDouble(t[1]);
					this.StableDist[2] = Double.parseDouble(t[2]);
					this.StableDist[3] = Double.parseDouble(t[3]);
					this.StableDist[4] = Double.parseDouble(t[4]);
					params++;
					continue;}
				
				if (args[i].equals("-r"))
					{this.r = (int)Math.round(Double.parseDouble(args[++i]));
					params++;
					continue;}
				if (args[i].equals("-rvar"))
					{this.rvar = Float.parseFloat(args[++i]);
					params++;
					continue;}
				if (args[i].equals("-R"))
					{this.R = Double.parseDouble(args[++i]);
					params++;
					continue;}
				if (args[i].equals("-Mx"))
					{this.MaxFlies = (int)Math.round(Double.parseDouble(args[++i]));
					params++;
					continue;}
				if (args[i].equals("-Dm"))
					{this.DevModel = (int)Math.round(Double.parseDouble(args[++i]));
					params++;
					continue;}
				if(args[i].equals("-Sai"))
					{this.SterileAfterIntervention=Boolean.parseBoolean(args[++i]);
					params++;
					}
				if (args[i].equals("-Tmax"))
					{this.Tmax = Double.parseDouble(args[++i]);
					params++;
					continue;}
				if (args[i].equals("-TuSD"))
					{this.TuSD = Double.parseDouble(args[++i]);
					params++;
					continue;}
				if (args[i].equals("-seed"))
					{this.seed = Long.parseLong(args[++i]);
					params++;
					continue;}
				
				if (args[i].equals("-S"))
					{this.S = Double.parseDouble(args[++i]);
					params++;
					continue;}
				
				if (args[i].equals("-T"))
					{this.Tfile=args[++i];
//					this.T = getTempsFromFile(Tfile, Tfile_skiplines);
					params++;
					continue;}
				if (args[i].equals("-Tskip"))
					{this.Tfile_skiplines = Long.parseLong(args[++i]);
					params++;
					continue;}
				
	/**			if (args[i].equals("-Os"))
					{this.Os = args[++i];
					params++;
					continue;}
				if (args[i].equals("-Od"))
					{this.Od = args[++i];
					params++;
					continue;}
				if (args[i].equals("-o"))
					{this.WriteOutputBool = Boolean.getBoolean(args[++i]);
					params++;
					continue;}	**/
				if (args[i].equals("-o"))
					{this.o = args[++i];
					params++;
					continue;}
				
				//@TG read spatial parameters from command line
				if (args[i].equals("-tg")){
					this.tgTrue = Boolean.parseBoolean(args[++i]);
				}
				if (args[i].equals("-tgf")){
					this.tgFile = Utilities.makeFileSystemPath(args[++i],false);
				}
				if (args[i].equals("-tgi")){
					this.tgIter=Integer.parseInt(args[++i]);
				}
				if (args[i].equals("-tgl")){
					this.tgLimit=Integer.parseInt(args[++i]);
				}
				if (args[i].equals("-tgd")){
					this.tgD=Double.parseDouble(args[++i]);
				}
				
				//@TG end read spatial parameters from command line
				
				if (args[i].equals("-q"))
					{this.Silent = Boolean.parseBoolean(args[++i]);
					params++;
					continue;}
				
				if (args[i].equals("-pm")) //this is a command-line-only option. For use with Medfoesp
				{this.ParallelMode = Boolean.parseBoolean(args[++i]);
				params++;
				continue;}
			
								
			}
			if (params < 16){
				System.out.print("WARNING::");
				System.out.println("There appear to be too few parameters");
				System.out.println("Expected minumum number of params is 16 "+" Number parsed is "+params);
			}
			
			// Deal with parameters which may depend on multiple arguments (Tfile and Tfile_skiplines for example)
			// Also where instansiated values directly from medfoesp go
			if( shared_params_set == false ){
				this.T = Utilities.getTempsFromFile(Tfile, Tfile_skiplines);
			}
		}
		
		//@TG
		//@TODO need to calculate this based on TrapGrid, DO THIS SOON
		/**
		 * Get the average escape probability for the given grid.
		 * @return the tgEscapeProb probability of escape (daily)
		 */
		public double [] getTgEscapeProb() {
			return tgEscapeProb;
		}


		/**
		 * Set the escape probability for the grid 
		 * @param tgEscapeProb the tgEscapeProb to set
		 */
		public void setTgEscapeProb(double [] tgEscapeProb) {
			this.tgEscapeProb = tgEscapeProb;
		}

		


}
