/**
 * Created 23 June 2015
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * Daniel K. Inouye US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 */
package gov.usda.ars.medfoes;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import com.reallymany.trapgrid.*;

/**
 * Wrapper to run TrapGrid simulations; follows the script in Driver.java (see TrapGrid.jar)
 * @author manoukis
 *
 */
public class TrapGridRunner {
	String tgFile;
	int tgIter;				// Number of trapgrid simulations to run
	private double [] tgEscapeProb;// Daily probability of escaping the trapgrid
	int tgLimit;		//limit trapping days
	double Dcoef;
	private TrapGrid tg;
	private Population p;
	
	public void setParameters (String tgFile, int tgIter,int tgLimit, double Dcoef, Population p){
		this.tgFile=tgFile;
		this.tgIter=tgIter;
		this.tgLimit=tgLimit;
		this.Dcoef=Dcoef;
		this.p=p;
	}
	
	/**
	 * Calculate TrapGrid escape probabilities, daily, for simulation length
	 * @return Daily escape probabilities
	 */
	public double [] run () {
		
		// Parameters that are FIXED
		int nFlies=500;
		//end Parameters that are fixed
		
		// Followed the basic script in Driver.java (TrapGrid.jar) in order to run the trapgrid sims and get back daily averages
		
		try {
			tg = new TrapGrid(tgFile);			
		} catch (NumberFormatException e) {
			System.err.println("Medfoes::TrapGridRunner: NumberFormatException with TrapGrid file");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Medfoes::TrapGridRunner: IOException with TrapGrid file");
			e.printStackTrace();
		}
		
		// Temporarily suppress System err output
		PrintStream oldErr = System.err;
		PrintStream newErr = new PrintStream(new ByteArrayOutputStream());
		System.setErr(newErr);
		
		SimulationRunner simRunner = new SimulationRunner(tg,tgLimit,nFlies,Dcoef,0,0,0,false,p.s.seed,tgIter);
		simRunner.runSimulations();
		
		SimulationResultsHolderAggregator agg = new SimulationResultsHolderAggregator(simRunner.allResults);
		newErr.flush();
		newErr.close();
		try { Thread.sleep(300); } catch (InterruptedException e) {} //wait for printstream to finish!
		System.setErr(oldErr); //reset stErr
		
		double []  out =returnDailyEscapeProbs(agg);
		return (out);
		
	}
	
	private double [] returnDailyEscapeProbs(SimulationResultsHolderAggregator agg){
		String s = agg.aggregrateSimulationResultsHolders();
		String [] lines = s.split("\n");
		double [] out = new double[lines.length-1];
		double curr = 1;
		for (int i=1;i<lines.length;i++){
			double val = Double.parseDouble(lines[i].split("\t")[1]);
			out[i-1]=curr-val;
			out[i-1]=1-out[i-1]; //now they are escape probabilities.
			curr=val;
		}
		return out;
	}

}
