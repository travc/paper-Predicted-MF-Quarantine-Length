/**
 * Created 22 July 2011
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 */
package gov.usda.ars.medfoes;

/**
 * The fly object in MED-FOES
 * 
 * This includes egg, larval instars, pupal and adult stages.
 *   
 * 
 * @author manoukis
 *
 */
public class Fly {
	
	
	int Stage;	// can be 0 ('egg'), 1('larvae'), 2('Pupa'), 3('Adult')
	int Mature;	// 0= sexually immature, 1=mature, lays eggs 1x per day.
	int Age; 		// hours
	int Dead;		// 0=alive; 1=dead
	Population p; 	// the parent population- contains developmental parameters
	LmProbGenerator lmp; // common probability generator.
	boolean nonEgg; // was this a fly spawned at a stage other than an egg
	boolean potentiallyReproductive; // is this fly able to reproduce? NOTE- not related to maturity!
	
	//Developmental parameters
	double BaseTemp; // Tmin for stage transitions 0 through 2.
	double K;		// K for stage transitions 0 through 2.
	double mBaseTemp; // Tmin for ovarian maturation
	double mK;			// K for ovarian maturation
	double MaxTemp; // the maximum temperature at which development can occur. This is set to 35C.
	double DevIntercept; // The Intercept of the linear developmental rate model (a)
	double DevSlope;	// The Slope of the linear developmental rate model (b)
	int DevModel; 	// how to progress through development: 0=uniform sampling 1=thermal unit accumulation
	
	
	double ThermHoursInStage; 	// the number of thermal hours accumulated in the current stage
	double DevModifier;			// the percent of total thermal units by which this individual will deviate from
								// the mean time to transition at a given temperature. Valid across all stages
	
	
	/**
	 * Make a fly. If unspecified, Flies are always created as eggs, with age = 0
	 * 
	 * @param BaseTemp Tmin
	 * @param K K
	 * @param mBaseTemp Tmin for transition to maturity as adult
	 * @param mK K for transition to maturity as adult
	 * @param p the parent population
	 * @param lmp LmProbGenerator that will be calculating transition probabilities
	 * @param DevModel Development model to be used: 0=uniform sampling, 1=thermal unit accumulation
	 * @param DevSD stochastic variation to be introduced into thermal unit transition time: SD of time to transition as a
	 * proportion of the time to transition
	 * @param Tmax Maximum temperature under which development for this fly can occur
	 */
	public Fly(double BaseTemp, double K, double mBaseTemp, double mK, Population p,LmProbGenerator lmp, int DevModel, double DevSD, double Tmax,boolean PotentiallyRepro){
		this.Stage=0;
		this.Age=0;
		this.p=p;
		this.lmp=lmp;
		this.nonEgg=false;
		this.Mature=0;
		
		this.BaseTemp=BaseTemp;
		this.K=K;
		this.mBaseTemp=mBaseTemp;
		this.mK=mK;
		
		this.MaxTemp=Tmax;
		this.DevIntercept=CalculateDevIntercept();
		this.DevSlope=CalculateDevSlope();
		this.DevModel=DevModel;
		
		this.ThermHoursInStage=0;
		
		if(DevModel==1){
			this.DevModifier = p.mr.nextGaussian(0, DevSD*DevSD);
		}
		this.potentiallyReproductive=PotentiallyRepro;
		
	}
	
	
	/**
	 * Make a fly. If unspecified, Flies are always created as eggs, with age =0
	 * 
	 * @param BaseTemp Tmin
	 * @param K K
	 * @param mBaseTemp Tmin for transition to maturity as adult
	 * @param mK K for transition to maturity as adult
	 * @param p the parent population
	 * @param lmp LmProbGenerator that will be calculating transition probabilities
	 * @param Stage stage at which to initialize this fly (will make flag 'nonEgg
	 * ==true
	 * @param Mature whether the adult is sexually mature (all other stages will not be mature).
	 * @param DevModel Development model to be used: 0=uniform sampling, 1=thermal unit accumulation
	 * @param DevSD stochastic variation to be introduced into thermal unit transition time: SD of time to transition as a
	 * proportion of the time to transition
	 * @param Tmax Maximum temperature under which development for this fly can occur
	 * 
	 */
	public Fly(double BaseTemp, double K, double mBaseTemp, double mK, Population p,LmProbGenerator lmp,int Stage, int Mature, int DevModel, double DevSD, double Tmax, boolean PotentiallyRepro){
		this.Stage=Stage;
		this.Age=0;
		this.p=p;
		this.lmp=lmp;
		this.nonEgg=true;
		if (Stage==3){
			this.Mature=Mature;
		}
		else{
			this.Mature=0;
		}
		
		this.BaseTemp=BaseTemp;
		this.K=K;
		this.mBaseTemp=mBaseTemp;
		this.mK=mK;
		this.MaxTemp=Tmax;
		this.DevIntercept=CalculateDevIntercept();
		this.DevSlope=CalculateDevSlope();
		this.DevModel=DevModel;
		
		this.ThermHoursInStage=0;
		
		if(DevModel==1){
			this.DevModifier = p.mr.nextGaussian(0, DevSD*DevSD);
		}
		
		this.potentiallyReproductive=PotentiallyRepro;
	}
	
	
	/**
	 * Set this fly to dead. It can then be removed from parent Populations Flies ArrayList. Also adds to the total number of flies which have died 
	 * so far (cumulative)
	 */
	public void die(){
		this.Dead=1;
	}
	
	
	
	/**
	 * Age the fly by 1 hour. Several stochastic events may here (in order): stage transition, reproduction, death from natural causes and
	 * death from human intervention 
	 * 
	 * Thanks to Brian Hall for work on the probabilities of hourly death.
	 * 
	 */
	public void Age(){
		Age++;
		
		// make sure nothing strange is happening
		
		if (Stage>3){
			System.err.println("Error in Fly::Age : Have stage > 3. This should be impossible. Aborting");
			System.exit(-1);
		}
		
		
		if (Stage == 3){
			// if fly is an adult but not sexually mature, check if maturity occurs.
			if (this.Mature==0){
				
				if(DevModel==0){ // uniform development model
					if (lmp.getTransitionFlagUnifrom(p.getCurrentTemp(),CalculateDevIntercept(mBaseTemp,mK),CalculateDevSlope(mK))==true){
						this.Mature++;
					}
				}
				else if (DevModel==1){ //thermal unit accumulation model
					if (p.getCurrentTemp()<=this.MaxTemp){
						this.ThermHoursInStage+=p.CurrentTemp-this.mBaseTemp;
					}
					
					
					if (this.ThermHoursInStage>(mK*24)+((mK*24)*DevModifier)){ //this means that the fly has accumulated enough therms to transition
						//double holdit = (mK*24)+((mK*24)*DevModifier);
						//System.out.println("therms req for maturity "+holdit);
						this.Mature++;
					}
					
				}
				else{
					System.err.print("ERROR in Fly::Age()\n Need a developmental model- one does not seem to be specified. See option 'Dm'\n");
					System.exit(-1);
				}
				

			}
			
			
		}
		
		else{
			// Do other stage transitions if fly is not an adult
			
			boolean transflag=false;
			
			// check if transition occurs under uniform model, if that is what we are using
			
			if (DevModel==0){ // using uniform transition probabilities
				if(p.getCurrentTemp()<=this.MaxTemp&&p.getCurrentTemp()>=BaseTemp){ // can only have chance of transition if above min and below maxtemp
					transflag=lmp.getTransitionFlagUnifrom(p.getCurrentTemp(),DevIntercept,DevSlope); // this is transition based on uniform distribution
				}
			}
			
			else if (DevModel==1){ // using a thermal unit accumulation model
				if (p.getCurrentTemp()<=this.MaxTemp){
					this.ThermHoursInStage+=p.CurrentTemp-this.BaseTemp;
				}
				
				
				if (this.ThermHoursInStage>(K*24)+((K*24)*DevModifier)){ //this means that the fly has accumulated enough therms to transition
					transflag=true;
				}
			}
			
			else{
				System.err.print("Error in Fly::Age()\n Need a developmental model- one does not seem to be specified. See option 'Dm'\n");
				System.exit(-1);
			}

			
			if (transflag==true){
			
				this.Stage++;
				this.ThermHoursInStage=0;
				// set new Tmin and K
				
				switch (Stage){
				case 0:{
					setDevelopmentalParameters(p.s.TEL[0],p.s.TEL[1]);
					break;
				}
				case 1:{
					setDevelopmentalParameters(p.s.TLP[0],p.s.TLP[1]);
					break;
				}
				case 2:{
					setDevelopmentalParameters(p.s.TPA[0],p.s.TPA[1]);
					break;
				}
				default: break;
			}
			}
		}
		
				
	
		
		
		// there is a probability that natural death will occur! Here we test whether death has occurred, using stage-specific
		// minimum and maximum daily mortality parameters. This stage-specific value (S_x) is the regular background rate of death.
		// There is also a temperature-dependent effect as per Guitierrez and Ponti 2011:
		// mu(egg-larval) = .0004T^2 -.0145T + .1314
		// mu(pupae)      = .0005T^2 -.0207T + .2142
		// mu(adults)     = .00049T^2 -.0187T + .1846
		
		double dprob=p.s.u.nextDouble(); //death probability
		double tdmCutOff;	// temp dependent mort cutoff
		double cutOff;		// non temp dependent mort cutoff
		double c; 			//an intermediary for moving between mortality and survivorship
		
		switch (Stage){
		case 0:{
			if (p.s.tempDepMortality==true){
				//System.out.println(p.CurrentTempDepMortalityEggs);
				c = (1-p.s.Me)*(1-p.CurrentTempDepMortalityEggs); // this is the prob of SURVIVING both sources of mortality; per DAY
				tdmCutOff = Math.pow(c, (double)1/24);  // prob of dying, per HOUR
				if (dprob>=tdmCutOff){
					die();
				}
			}
			else{ 
				cutOff=Math.pow(1-p.s.Me, (double)1/24);  //not temp dep mortality
				if(dprob>=cutOff){
					die();
				}
			}
			break;
		}
		case 1:{
			if (p.s.tempDepMortality==true){
				c = (1-p.s.Ml)*(1-p.CurrentTempDepMortalityLarvae); // this is the prob of SURVIVING both sources of mortality; per DAY
				tdmCutOff = Math.pow(c, (double)1/24);  // prob of dying, per HOUR
				if (dprob>=tdmCutOff){
					die();
				}
			}
			else{
				cutOff=Math.pow(1-p.s.Ml, (double)1/24);  //not temp dep mortality
				if(dprob>=cutOff){
					die();
				}
			}
			break;
		}
		case 2:{
			if (p.s.tempDepMortality==true){
				c = (1-p.s.Mp)*(1-p.CurrentTempDepMortalityPupae); // this is the prob of SURVIVING both sources of mortality; per DAY
				tdmCutOff = Math.pow(c, (double)1/24);  // prob of dying, per HOUR
				if (dprob>=tdmCutOff){
					die();
				}
			}
			else{
				cutOff=Math.pow(1-p.s.Mp, (double)1/24);  //not temp dep mortality
				if(dprob>=cutOff){
					die();
				}
			}
			break;
		}
		case 3:{
			if (p.s.tempDepMortality==true){
				if(p.s.hours>p.s.R*24){
					c = (1-p.s.Ma)*(1-p.CurrentTempDepMortalityAdults)*(1-p.s.S); // this is the prob of SURVIVING both sources of mortality; per DAY
					tdmCutOff = Math.pow(c, (double)1/24);  // temp dependent mortality
					if (dprob>=tdmCutOff){
						die();
					}
				}
				else{
					c=(1-p.CurrentTempDepMortalityAdults)*(1-p.s.Ma);
					tdmCutOff = Math.pow(c, (double)1/24);  // temp dependent mortality
					if (dprob>=tdmCutOff){
						die();
					}
				}

			}
			else{
				if(p.s.hours>p.s.R*24){
					c = (1-p.s.Ma)*(1-p.s.S); // this is the prob of SURVIVING both sources of mortality; per DAY
					cutOff = Math.pow(c, (double)1/24);
					if(dprob>=cutOff){
						die();
					}
				}
				else{
					cutOff=Math.pow(1-p.s.Ma, (double)1/24);  //not temp dep mortality
					if(dprob>=cutOff){
						die();
					}
				}
			}
			break;
		}
		default: break;
		}
		
		// check if this individual is > 6 months old. If so, die.
	//	if (this.Age>4320){
	//		die();
	//	}
	
		
		// check if reproduction or loss of ability to reproduce might occur. 
		if (this.Stage==3 &&  this.Mature!=0 && p.s.hours%24==0 && this.potentiallyReproductive==true&&this.Dead!=1){
			
			// this fly may lose ability to reproduce if time is > R; probability of loss per day is set by rred. 
			if (p.s.hours>p.s.R*24){
				if (p.s.u.nextDouble()<p.s.rred){
					this.potentiallyReproductive=false;
				}	
			}
			
			if (this.potentiallyReproductive==true){
				// if still reproductive, calculate number of eggs produced. Add them to population.
				int e = (int) p.mr.nextGaussian((double)p.s.r,p.s.rvar);
				p.EggsToAdd+= e;
			}
			
		}
		
		// @TG Death from a trap (TrapGrid)
		if (this.Mature==1&&p.s.tgTrue==true){	//fly must be sexually mature, and we must be using spatial trapping
			double tprob=p.s.u.nextDouble(); //to be used against death by trap probability.
			if (tprob<1-Math.pow(this.p.s.getTgEscapeProb()[p.s.hours/24], (double)1/24)){
				this.die();
	//			System.out.println("Trapping death!");
			}
		}
		
	}
	
	
	
	
	/**
	 * Change Tmin and K for the fly and recalculate intercept and slope of transition probabilities. Also
	 * reset therm hours in stage
	 * Must be called when stage transition occurs.
	 * @param Tmin
	 * @param K
	 */
	public void setDevelopmentalParameters(double Tmin, double K){
		this.BaseTemp=Tmin;
		this.K=K;
		this.DevIntercept=CalculateDevIntercept();
		this.DevSlope=CalculateDevSlope();
		
		this.ThermHoursInStage=0; //reset therm hours also
	}
	
	
	/**
	 * Calculate the intercept of the linear relationship between temp and 1/(time to transition) [=developmental rate]
	 * @return the intercept of the linear model. Call without args to use current BaseTemp and K.
	 */
	private double CalculateDevIntercept(){
		double ret = -BaseTemp*(1/K);
		return ret;
	}
	
	/**
	 * Calculate the slope of the linear relationship between temp and 1/(time to transition) [=developmental rate]
	 * @return the slope of the linear model. Call without args to use current K.
	 */
	private double CalculateDevSlope(){
		double ret = 1/K;
		return ret;
	}
	
	
	/**
	 * Calculate the intercept of the linear relationship between temp and 1/(time to transition) [=developmental rate]
	 * @return the intercept of the linear model.
	 * @param BaseTemp Base temperature to use
	 * @param K K to use
	 */
	private double CalculateDevIntercept(double BaseTemp, double K){
		double ret = -BaseTemp*(1/K);
		return ret;
	}
	
	/**
	 * Calculate the slope of the linear relationship between temp and 1/(time to transition) [=developmental rate]
	 * @return the slope of the linear model.
	 * @param K K to use
	 */
	private double CalculateDevSlope(double K){
		double ret = 1/K;
		return ret;
	}
	
	/**
	 * Returns current Tmin for this Fly.
	 * @return Tmin
	 */
	public double getBaseTemp() {
		return BaseTemp;
	}
	
	/**
	 * Sets Tmin for this Fly.
	 * @param Base Tmin
	 */
	public void setBaseTemp(double Base) {
		BaseTemp = Base;
	}
	
	
	/**
	 * Returns current K for this Fly.
	 * @return K
	 */
	public double getK() {
		return K;
	}
	
	/**
	 * Set K for this Fly.
	 * @param K
	 */
	public void setK(double K) {
		this.K=K;
	}
	

}
