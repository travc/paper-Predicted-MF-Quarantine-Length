/**
 * Created 22 Oct 2013
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 */
package gov.usda.ars.medfoesp;

import gov.usda.ars.medfoes.Utilities;

/**
 * Class for aggregating results from separate Medfoesp threads.
 * @author manoukis
 *
 */
public class ResultHolder {
	
	double [] times;	//number of hours simulated **run time**	
	double [] numbers;	//numbers at end of sims
	int [] end_conditions; // end condition code for each run (0=Extirpation, 1=Out of temps, 2=Too many flies)
	int resultNumber; // position in the array
	int numRuns;	// total number of runs
	Medfoesp mfp;	//parent object
	public boolean showPlot;	//whether to plot figures
	
	/**
	 * Default constructor. Does nothing but initialize variables for storage.
	 * @param numRuns Number of results this ResultHolder can expect.
	 */
	public ResultHolder(int numRuns, Medfoesp mfp){
	//	ArrayList<String> times = (ArrayList<String>) Collections.synchronizedList(new ArrayList<String>());
	//	ArrayList<String> numbers = (ArrayList<String>) Collections.synchronizedList(new ArrayList<String>());
		this.resultNumber=0;
		this.numRuns=numRuns;
		this.mfp=mfp;
		this.times=new double [numRuns];
		this.numbers=new double[numRuns];
		this.end_conditions=new int[numRuns];
		this.showPlot=mfp.showPlot;
		
//		 this.times = new LinkedList();
//		 this.numbers = new LinkedList();
	}
	
	/**
	 * Adds another set of results to the object
	 * @param input
	 */
	public synchronized void AddSummaryResults(double [] input){
//		times.add(input[0]);
//		numbers.add(input[1]);
		times[resultNumber] = input[0];
		numbers[resultNumber] = input[1];
		end_conditions[resultNumber] = (int)input[2];
		resultNumber++;
		if (mfp.Silent==false){
			if(resultNumber%25==0){
				System.out.println(resultNumber+"/"+numRuns);
			}
		}
		
	}
	
//	public double [] getTimes(){
//		double [] out = new double [times.size()];
//		ListIterator itr = times.listIterator();
//		int n =0;
//		
//		 while(itr.hasNext()){
//			 out[n]=(Double) itr.next();
//			 n++;
//		 }
//		return out;
//		
//	}
	
	/**
	 * Returns the number of days that the simulations ran (to extirpation or end of Temperatures). Should only be called when threads are complete.
	 * @return Array of times.
	 */
	public double[] getTimes(){
		return this.times;
	}
	
	
	/**
	 * Returns the number of flies left at the end of the simulations that ran. Should only be called when threads are complete.
	 * @return Array of numbers.
	 */
	public double [] getNumbers(){
		return this.numbers;
		
	}

	/**
	 * Get the mean[SD] for the run lengths and for number of flies at the end of simulations. 
	 * @return mean[SD] for run length (element 0) and time (element 1)
	 */
	public String [] getMeanRunLengthAndNumbers() { // element 0 of return=mean/sd of run length; element 1 is same, for number of flies at end
		double [] t=Utilities.getMeanAndSD(times);
		double [] n=Utilities.getMeanAndSD(numbers);
		
		String[]o=new String[2];
		o[0]=Double.toString(t[0])+" ["+Double.toString(t[1])+"] ";
		o[1]=Double.toString(n[0])+" ["+Double.toString(n[1])+"] ";
		
		return o;
	}
	
	
	public double getTimePercentiles(double p){
		return Utilities.getPercentile(times, p);
	}
	
	/**
	 * get the percent of the completed simulations that have shown extirpation.
	 * @return percent with pop size=0 at end of simulation
	 */
	public String getPercentExtirpation(){
		double n=0;
		for (int y=0;y<numbers.length;y++){
			if (numbers[y]!=0){
				n++;
			}
		}
		return Double.toString((1-(n/numbers.length))*100);
	}

}
