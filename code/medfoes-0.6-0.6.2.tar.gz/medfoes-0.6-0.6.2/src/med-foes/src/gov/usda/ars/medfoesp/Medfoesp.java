/**
 * Created 20 Oct 2013
 * 
 * N.C. Manoukis
 * Agricultural Research Service, USDA
 * US Pacific Basin Agricultural Research Station
 * Hilo Hawaii USA
 * 
 */
package gov.usda.ars.medfoesp;


import gov.usda.ars.LHS.LHSMaster;
import gov.usda.ars.medfoes.Utilities;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.xeiam.xchart.BitmapEncoder;




/**
 * Program for running multiple MED-FOES simulations in parallel. This class takes single parameters or ranges for each
 * simulation parameter. For those that are ranges, it will generate a set of simulation run commands using LHS, run them 
 * using a specified number of threads, and then summarize the results in text files and figures. Raw run outputs are also 
 * stored.
 * 
 * @author manoukis
 *
 */
public class Medfoesp {
	// Parameters needed to run a simulation are seen below; some will be RANGES, as this is MED-FOESp
	// any parameter that ends with "V" is one that has a range associated with it.
	double [] NiV;			// VARY number of adult females at start of simulation
	double [] MeV;		// VARY estimated daily mortality of eggs
	double [] MaV;		// VARY estimated daily mortality of adults
	double [] MlV;		// VARY estimated daily mortality of larvae
	double [] MpV;		// VARY estimated daily mortality of pupae
	double [] TELV;		// VARY Tmin [0] and K [1] for transition from egg to larvae (hatching rate/day)
	double [] TLPV;		// VARY Tmin [0] and K [1] for transition from larvae to pupae (pupation rate/day)
	double [] TPAV;		// VARY Tmin [0] and K [1] for transition from pupae to adult (emergence rate/day)
	double [] TIMV;		// VARY Tmin [0] and K [1] for transition from immature to mature adult (ovarian maturation rate/day)
	double [] rV;			// VARY number of eggs produced by female per reproduction
	float rvar;		// FIXED variance in the number of eggs produced per female per reproduction
	double [] rredV;	// VARY proportion of population that loses the ability to reproduce per day after R. required.
	double [] SV;		// VARY eradication pressure from countermeasures on adults (rate- proportion all adults killed per day)
	double R;		// FIXED time from first find to start of quarantine (start of eradication pressure)
	int MaxFlies;	// FIXED maximum number of flies allowed to be alive before simulation exits (optional)
	int DevModel; 	// FIXED how to progress through development: 0=uniform sampling 1=thermal unit accumulation
	boolean SterileAfterIntervention;	// FIXED whether flies produced after the intervention are all sterile. 
	double Tmax;	// FIXED maximum temperature at which development can occur
	double TuSD;	// FIXED Standard deviation about the mean thermal units needed for stage transition *as a proportion of mean*
	//@TG spatial parameters
	boolean tgTrue;	// FIXED whether to use spatial trapping
	String tgFile; // FIXED trapgrid file
	static int tgIter=1;		// FIXED number of trapping simulations
	int tgLimit;	// FIXED number of days for which to run each simulation
	double [] tgDV;		// VARY diffusion parameter for spatial trapping simulation
	//@TG end spatial parameters
	double [] StableDist; 	// FIXED percent individuals in each of 5 classes of stable age distribution. Default is Carey 1982.
	boolean tempDepMortality; // FIXED whether mortality is temperature dependent or fixed daily rate. Optional, default=fixed daily rate
	long seed;
	boolean preview;		// Whether to just generate commands, not run them
	public boolean showPlot;
	
//	boolean WriteOutputBool; // whether to have outfiles or put output on console; true=write to file
	String o;				// FIXED This is an output DIRECTORY
	public boolean Silent;			// FIXED whether to be chatty on the console; if true, only results are shown on console or written to files after run
	String Tfile;	// FIXED filename where temps are
	long Tfile_skiplines = 0; // FIXED num of initial temperature vals in Tfile to skip
	
	// Parameters special to medfoesp: parallelization stuff.
	int nThreads; // number of execution threads ("nT")
	int nRuns;	// total number of runs ("nR")
	String [] lhscommand;
	// pre-loaded/computed values used by child runs
	double[] T; // Temperature values loaded from Tfile
	
	// objects for holding results (from each simulation)
	ResultHolder r;
	
	String version;
	private String StartTime;
	private String shortStartTime;

	/**
	 * Default method
	 * @param args parameters
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		Medfoesp MFp = new Medfoesp();
		MFp.version="0.6";
		MFp.run(args);
		
	}

	/**
	 * The constructor. See docs for more details on parameters.
	 * 
	 * @param args
	 * @throws InterruptedException
	 */
	private void run(String[] args) throws InterruptedException {

		StartTime=getDateTime();
		shortStartTime=StartTime.replace("/","-").replace(" ", "_").replace(":", "-");//I'm not proud of this. But it works.
		if (args.length <2) {
			if (args[0].equalsIgnoreCase("-v")){
				System.out.println("MED-FOESp version "+version);
				System.exit(0);
			}
			
			System.err.println("Usage:  java med-foesp.jar -f paramfileName [-parameter value ..]");
			System.exit(-1);
		}
		
		try {
			loadSimulationParameters(args);
		} 
		catch (IOException e) {
			System.err.println("problem with infile");
			e.printStackTrace();
			System.exit(-1);
		}
		if (Silent == false){
			System.out.print("Loading simulation parameters ...");
			System.out.print("DONE\n");
		}


		
		File f = new File(o+"Runs");
		if (f.exists()==true){
			System.out.println("Warning: Runs directory already exists; results may be comingled or clobbered");
		}
		
		else{
			// Create a directory; all non-existent ancestor directories are
			// automatically created
			boolean success = (new File(o+"Runs")).mkdirs();
			if (!success) {
			    // Directory creation failed
				System.err.println("Failed to create Runs directory- check location, permission. Error in Medfoesp::run");
				System.exit(-1);
			}
		}

		
		
		// Run LHSMaster to get all run command lines
		LHSMaster lhsm = new LHSMaster();
		lhsm.setnSlices(nRuns);
		lhsm.setPre("medfoes.jar");
		if (StableDist!=null){
			lhsm.setPost("-Ad "+ArrayToString(DoubleArrayToStringArray(StableDist))+"-o "+o+"Runs/"+shortStartTime+"_run");
		}
		else{
			lhsm.setPost("-o "+o+"Runs/"+shortStartTime+"_run");
		}
	//	String [] tmp = new String[]{"100","medfoes.jar","/home/manoukis/hold_temp/LHS_infile.txt","/home/manoukis/hold_temp/Runs/run"};
	//	lhsm.run(tmp);
		File file = new File(o+"Simulation_commands_"+shortStartTime+".txt");
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file);
		} catch (FileNotFoundException e1) {
			System.err.println("ERROR in Medfoesp::run: Could not touch Simulation_commands file");
			e1.printStackTrace();
		}
		PrintStream ps = new PrintStream(fos);
		PrintStream original = new PrintStream(System.out);
		
		System.setOut(ps);
		lhsm.run(lhscommand);
		System.setOut(original);
		
		// initialize result holders before running
//		try{
//			// TODO need to think about what to put here.
//		}
//		catch (Exception e){
//			System.out.println("ERROR in Medfoesp::run.");
//			e.printStackTrace();
//			System.exit(-1);
//		}
		
		// here, run all the simulations- THREAD
		
		if (preview==false){
			String [] theRuns = null;
			
			try {
				theRuns = readLines(o+"Simulation_commands_"+shortStartTime+".txt");
			} catch (IOException e) {
				System.err.println("Fatal error reading Simulation Run commands; this should not happen. Medfoesp::run");
				e.printStackTrace();
				System.exit(-1);
			}
			
			

			
			Tasker tasker = new Tasker(theRuns, this.T);
			CountDownLatch l = new CountDownLatch(nThreads);
			r = new ResultHolder(nRuns,this);
			
//			ExecutorService es = Executors.newFixedThreadPool(nThreads);
//			for (int i = 0; i < nThreads; i++) {
//				es.execute(new SimRunner(tasker,r,l));
//				}
//			es.shutdown();
			
			Thread [] threads = new Thread[nThreads];
			SimRunner [] Sims = new SimRunner[nThreads];	
			if (Silent==false){
				System.out.println("Spawning worker threads; Progress:");
			}
			
			for (int i=0;i<nThreads;i++){
				Sims[i]=new SimRunner(tasker,r,l);
				threads[i]=new Thread(Sims[i]);
				threads[i].start();
			}
			
			l.await(); // wait for threads to complete
			
			// Write summary File
			WriteSummaryFile();
			WriteDetailFile();
			
			// Produce output statistics	
			if( this.showPlot ){
				try { Thread.sleep(300); } catch (InterruptedException e) {} //try to flush before plotting.
				Plotter plotter = new Plotter(r);
				try {
					plotter.generateFigures(o,StartTime.replace("/","-").replace(" ", "_").replace(":", "-"));
				} catch (IOException e) {
					System.err.println("Error plotting figures: Medfoesp::run");
					e.printStackTrace();
				}
			}	
			// end real runs
		}		
	}
	

	/**
	 * This method reads in parameters, either from a file or from the command line or 
	 * both. Note that command line parameters over ride those in any infile. Also, 
	 * command line does NOT take size and migration arrays. It takes a min, max and 
	 * step number and the array is generated internally.
	 * @param args The param file name or run time parameters.
	 * @throws IOException
	 */	
		protected void loadSimulationParameters(String [] args) throws IOException {
			int params = 0;
			boolean file = false;
			String inputFile="";
			String tmp;

			for (int i=0;i<args.length ;i++ ) {
				if (args[i].equals("-f")) {
					file = true;
					inputFile = args[i+1];
					break;
				}
			}

			if (file==true){
				FileInputStream is = new FileInputStream(inputFile);
				try {
					Properties p = new Properties();
					p.load(is);
					params += p.size(); //this is bad.
					this.NiV=new double[2];
					this.NiV[0] = Double.parseDouble(p.getProperty("Ni").split(",")[0]);
					this.NiV[1] = Double.parseDouble(p.getProperty("Ni").split(",")[1]);
					/** example of reading in array

					String [] t2 = p.getProperty("s1").split(",");
					this.sizesP1 = new int [t2.length];
					for (int u=0;u<t2.length;u++){
						this.sizesP1[u]=Integer.parseInt(t2[u]);
					}
					 */
					
					this.nThreads=Integer.parseInt(p.getProperty("nT"));
					this.nRuns=Integer.parseInt(p.getProperty("nR"));
					
					this.rredV=new double[2];
					this.rredV[0] = Double.parseDouble(p.getProperty("rred").split(",")[0]);
					this.rredV[1] = Double.parseDouble(p.getProperty("rred").split(",")[1]);
					this.tempDepMortality = Boolean.parseBoolean(p.getProperty("tdm"));
					
					this.MeV=new double[2]; this.MaV=new double[2]; this.MlV=new double[2]; this.MpV=new double[2];
					this.MaV[0] = Double.parseDouble(p.getProperty("Ma").split(",")[0]);
					this.MeV[0] = Double.parseDouble(p.getProperty("Me").split(",")[0]);
					this.MlV[0] = Double.parseDouble(p.getProperty("Ml").split(",")[0]);
					this.MpV[0] = Double.parseDouble(p.getProperty("Mp").split(",")[0]);
					this.MaV[1] = Double.parseDouble(p.getProperty("Ma").split(",")[1]);
					this.MeV[1] = Double.parseDouble(p.getProperty("Me").split(",")[1]);
					this.MlV[1] = Double.parseDouble(p.getProperty("Ml").split(",")[1]);
					this.MpV[1] = Double.parseDouble(p.getProperty("Mp").split(",")[1]);

					this.TELV=new double[4];
					this.TLPV=new double[4];
					this.TPAV=new double[4];
					this.TIMV=new double[4];
					
					this.TELV[0] = Double.parseDouble(p.getProperty("TEL").split(",")[0]);
					this.TELV[1] = Double.parseDouble(p.getProperty("TEL").split(",")[1]);
					this.TELV[2] = Double.parseDouble(p.getProperty("TEL").split(",")[2]);
					this.TELV[3] = Double.parseDouble(p.getProperty("TEL").split(",")[3]);
					this.TLPV[0] = Double.parseDouble(p.getProperty("TLP").split(",")[0]);
					this.TLPV[1] = Double.parseDouble(p.getProperty("TLP").split(",")[1]);
					this.TLPV[2] = Double.parseDouble(p.getProperty("TLP").split(",")[2]);
					this.TLPV[3] = Double.parseDouble(p.getProperty("TLP").split(",")[3]);
					this.TPAV[0] = Double.parseDouble(p.getProperty("TPA").split(",")[0]);
					this.TPAV[1] = Double.parseDouble(p.getProperty("TPA").split(",")[1]);
					this.TPAV[2] = Double.parseDouble(p.getProperty("TPA").split(",")[2]);
					this.TPAV[3] = Double.parseDouble(p.getProperty("TPA").split(",")[3]);
					this.TIMV[0] = Double.parseDouble(p.getProperty("TIM").split(",")[0]);
					this.TIMV[1] = Double.parseDouble(p.getProperty("TIM").split(",")[1]);
					this.TIMV[2] = Double.parseDouble(p.getProperty("TIM").split(",")[2]);
					this.TIMV[3] = Double.parseDouble(p.getProperty("TIM").split(",")[3]);
					
					this.rV=new double[2];
					this.rV[0] = Integer.parseInt(p.getProperty("r").split(",")[0]);
					this.rV[1] = Integer.parseInt(p.getProperty("r").split(",")[1]);
					
					this.rvar = Float.parseFloat(p.getProperty("rvar"));
					this.R = Double.parseDouble(p.getProperty("R"));
					this.MaxFlies = Integer.parseInt(p.getProperty("Mx"));
					
					
					if (p.containsKey("Ad")){
						String [] j = p.getProperty("Ad").split(",");
						this.StableDist=new double[5];
						for (int y=0;y<5;y++){
							this.StableDist[y]=Double.parseDouble(j[y]);
						}
					}
					
					if (p.containsKey("Sai")){
						this.SterileAfterIntervention=Boolean.parseBoolean(p.getProperty("Sai"));
					}
					
					if (p.containsKey("Dm")){
						this.DevModel = Integer.parseInt(p.getProperty("Dm"));
						this.TuSD = Double.parseDouble(p.getProperty("TuSD"));
					}
					else{
						this.DevModel=0;
					}
					
					this.Tmax = Double.parseDouble(p.getProperty("Tmax"));
					
					if (p.containsKey("seed")){
						this.seed = Long.parseLong(p.getProperty("seed"));
					}
										
					
					this.SV = new double [2];
					this.SV[0]= Double.parseDouble(p.getProperty("S").split(",")[0]);
					this.SV[1]= Double.parseDouble(p.getProperty("S").split(",")[1]);
					
					
					this.Tfile = Utilities.makeFileSystemPath(p.getProperty("T"),false);
					tmp = p.getProperty("Tskip");
					this.Tfile_skiplines = tmp == null ? 0 : Long.parseLong(tmp);
			//		this.T = getTempsFromFile(Tfile);
					if (p.containsKey("o")){
						this.o = Utilities.makeFileSystemPath(p.getProperty("o"),true);
					}
					else{
						this.o=null;
					}
					
					//@TG load spatial parameters from a FILE!
					if (p.containsKey("tg")){
						this.tgTrue=Boolean.parseBoolean(p.getProperty("tg"));
					}
					
					
					if (this.tgTrue==true){
						//Make sure we have all required spatial parameters
						int err=0;
						if (p.containsKey("tgf")==false){
							System.err.println("Parameter Error: Spatial option (tg=true) requires tgf");
							err++;
						}
						//if (p.containsKey("tgi")==false){
						//	System.err.println("Parameter Error: Spatial option (tg=true) requires tgi");
						//	err++;
						//}
						if (p.containsKey("tgl")==false){
							System.err.println("Parameter Error: Spatial option (tg=true) requires tgl");
							err++;
						}
						if (p.containsKey("tgd")==false){
							System.err.println("Parameter Error: Spatial option (tg=true) requires tgd");
							err++;
						}
						if (err>0){
							System.err.println(err+" spatial parameter values needed..exiting");
							System.exit(-1);
						}
						
						this.tgFile = Utilities.makeFileSystemPath(p.getProperty("tgf"),false);
					//	this.tgIter = Integer.parseInt(p.getProperty("tgi"));
						this.tgLimit = Integer.parseInt(p.getProperty("tgl"));
						this.tgDV = new double[2];
						this.tgDV[0] = Double.parseDouble(p.getProperty("tgd").split(",")[0]);
						this.tgDV[1] = Double.parseDouble(p.getProperty("tgd").split(",")[1]);
					}
					//@TG end spatial parameter reading from file.
					
					
					this.Silent = Boolean.parseBoolean(p.getProperty("q"));
					
					if (p.containsKey("pr")){
						this.preview=Boolean.parseBoolean(p.getProperty("pr"));
					}
					else{
						this.preview=false;
					}
					
					if (p.containsKey("plot")){
						this.showPlot=Boolean.parseBoolean(p.getProperty("plot"));
					}
					else{
						this.showPlot=false;
					}
					
				}
				catch (FileNotFoundException ex)
				{
					System.out.println("ERROR in Simulation::loadSimulationParameters: could not load infile: " + inputFile);
					ex.printStackTrace();
					System.exit(1);
				}
				}

			//This section reads the parameters sent in the command line and overrides the parameters in the parameters file
			
			for (int i=0;i<args.length ;i++ )
			{
				/**
				 * Again, sample for doing an array.
				
				if (args[i].equalsIgnoreCase("-s0"))
					{String [] t = args[++i].split(",");
					this.sizesP0 = new int [t.length];
					for (int u=0;u<t.length;u++){
						this.sizesP0[u]=Integer.parseInt(t[u]);
						}
					params++;
					continue;}
					
				 */
				
				if (args[i].equals("-nT"))
				{
					this.nThreads=(int)Math.round(Double.parseDouble(args[++i]));
					params++;
					continue;
				}
				
				if (args[i].equals("-nR"))
				{
					this.nRuns=(int)Math.round(Double.parseDouble(args[++i]));
					params++;
					continue;
				}
				
				if (args[i].equals("-Ni"))
					{String [] t = args[++i].split(",");
					this.NiV = new double [t.length];
					this.NiV[0] = Double.parseDouble(t[0]);
					this.NiV[1] = Double.parseDouble(t[1]);
					params++;
					continue;}
				//if (args[i].equals("-Ni"))
				//	{this.Ni = Integer.parseInt(args[++i]);
				//	params++;

				if (args[i].equals("-Ma"))
					{
					String [] t = args[++i].split(",");
					this.MaV = new double [t.length];
					this.MaV[0] = Double.parseDouble(t[0]);
					this.MaV[1] = Double.parseDouble(t[1]);
					params++;
					continue;}
				if (args[i].equalsIgnoreCase("-Me"))
					{String [] t = args[++i].split(",");
					this.MeV = new double [t.length];
					this.MeV[0] = Double.parseDouble(t[0]);
					this.MeV[1] = Double.parseDouble(t[1]);
					params++;
					continue;}
					if (args[i].equals("-Ml"))
					{String [] t = args[++i].split(",");
					this.MlV = new double [t.length];
					this.MlV[0] = Double.parseDouble(t[0]);
					this.MlV[1] = Double.parseDouble(t[1]);
					params++;
					continue;}
					if (args[i].equals("-Mp"))
					{String [] t = args[++i].split(",");
					this.MpV = new double [t.length];
					this.MpV[0] = Double.parseDouble(t[0]);
					this.MpV[1] = Double.parseDouble(t[1]);
					params++;
					continue;}
					
					if (args[i].equals("-tdm"))
					{this.tempDepMortality = Boolean.parseBoolean(args[++i]);
					params++;
					continue;}
					
					if (args[i].equals("-rred"))
					{String [] t = args[++i].split(",");
					this.rredV = new double [t.length];
					this.rredV[0] = Double.parseDouble(t[0]);
					this.rredV[1] = Double.parseDouble(t[1]);
					params++;
					continue;}
				
				if (args[i].equals("-TEL"))
					{String [] t = args[++i].split(",");
					this.TELV = new double [t.length];
					this.TELV[0] = Double.parseDouble(t[0]);
					this.TELV[1] = Double.parseDouble(t[1]);
					this.TELV[2] = Double.parseDouble(t[2]);
					this.TELV[3] = Double.parseDouble(t[3]);
					params++;
					continue;}
				if (args[i].equals("-TLP"))
					{String [] t = args[++i].split(",");
					this.TLPV = new double [t.length];
					this.TLPV[0] = Double.parseDouble(t[0]);
					this.TLPV[1] = Double.parseDouble(t[1]);
					this.TLPV[2] = Double.parseDouble(t[2]);
					this.TLPV[3] = Double.parseDouble(t[3]);
					params++;
					continue;}
				if (args[i].equals("-TPA"))
					{String [] t = args[++i].split(",");
					this.TPAV = new double [t.length];
					this.TPAV[0] = Double.parseDouble(t[0]);
					this.TPAV[1] = Double.parseDouble(t[1]);
					this.TPAV[2] = Double.parseDouble(t[2]);
					this.TPAV[3] = Double.parseDouble(t[3]);
					params++;
					continue;}
				if (args[i].equals("-TIM"))
					{String [] t = args[++i].split(",");
					this.TIMV = new double [t.length];
					this.TIMV[0] = Double.parseDouble(t[0]);
					this.TIMV[1] = Double.parseDouble(t[1]);
					this.TIMV[2] = Double.parseDouble(t[2]);
					this.TIMV[3] = Double.parseDouble(t[3]);
					params++;
					continue;}
				
				if (args[i].equals("-Ad"))
					{String [] t = args[++i].split(",");
					this.StableDist = new double [t.length];
					this.StableDist[0] = Double.parseDouble(t[0]);
					this.StableDist[1] = Double.parseDouble(t[1]);
					this.StableDist[2] = Double.parseDouble(t[2]);
					this.StableDist[3] = Double.parseDouble(t[3]);
					this.StableDist[4] = Double.parseDouble(t[4]);
					params++;
					continue;}
				
				if (args[i].equals("-r"))
					{String [] t = args[++i].split(",");
					this.rV = new double [t.length];
					this.rV[0] = (int)Math.round(Double.parseDouble(t[0]));
					this.rV[1] = (int)Math.round(Double.parseDouble(t[1]));
					params++;
					continue;}
				if (args[i].equals("-rvar"))
					{this.rvar = Float.parseFloat(args[++i]);
					params++;
					continue;}
				if (args[i].equals("-R"))
					{this.R = Double.parseDouble(args[++i]);
					params++;
					continue;}
				if (args[i].equals("-Mx"))
					{this.MaxFlies = (int)Math.round(Double.parseDouble(args[++i]));
					params++;
					continue;}
				if (args[i].equals("-Dm"))
					{this.DevModel = (int)Math.round(Double.parseDouble(args[++i]));
					params++;
					continue;}
				if(args[i].equals("-Sai"))
					{this.SterileAfterIntervention=Boolean.parseBoolean(args[++i]);
					params++;
					}
				if (args[i].equals("-Tmax"))
					{this.Tmax = Double.parseDouble(args[++i]);
					params++;
					continue;}
				if (args[i].equals("-TuSD"))
					{this.TuSD = Double.parseDouble(args[++i]);
					params++;
					continue;}
				if (args[i].equals("-seed"))
				{this.seed = Long.parseLong(args[++i]);
				params++;
				continue;}
				
				if (args[i].equals("-S"))
					{String [] t = args[++i].split(",");
					this.SV = new double [t.length];
					this.SV[0] = Double.parseDouble(t[0]);
					this.SV[1] = Double.parseDouble(t[1]);
					params++;
					continue;}
				
				if (args[i].equals("-T"))	
					{this.Tfile = Utilities.makeFileSystemPath(args[++i],false);
					//this.T = getTempsFromFile(Tfile);
					params++;
					continue;}
				if (args[i].equals("-Tskip"))
					{this.Tfile_skiplines = Long.parseLong(args[++i]);
					params++;
					continue;}
				
	/**			if (args[i].equals("-Os"))
					{this.Os = args[++i];
					params++;
					continue;}
				if (args[i].equals("-Od"))
					{this.Od = args[++i];
					params++;
					continue;}
				if (args[i].equals("-o"))
					{this.WriteOutputBool = Boolean.getBoolean(args[++i]);
					params++;
					continue;}	**/
				if (args[i].equals("-o"))
					{this.o = Utilities.makeFileSystemPath(args[++i],true);
					params++;
					continue;}
				
				//@TG read spatial parameters from command line
				if (args[i].equals("-tg")){
					this.tgTrue = Boolean.parseBoolean(args[++i]);
				}
				if (args[i].equals("-tgf")){
					this.tgFile = Utilities.makeFileSystemPath(args[++i],false);
				}
			//	if (args[i].equals("-tgi")){
			//		this.tgIter=Integer.parseInt(args[++i]);
			//	}
				if (args[i].equals("-tgl")){
					this.tgLimit=Integer.parseInt(args[++i]);
				}
				if (args[i].equals("-tgd")){
					this.tgDV=new double[2];
					String [] t = args[++i].split(",");
					this.tgDV[0]=Double.parseDouble(t[0]);
					this.tgDV[1]=Double.parseDouble(t[1]);
				}
				
				//@TG end read spatial parameters from command line
				
				if (args[i].equals("-pr"))
					{this.preview = Boolean.parseBoolean(args[++i]);
					params++;
					continue;}
				if (args[i].equals("-plot"))
				{this.showPlot = Boolean.parseBoolean(args[++i]);
				params++;
				continue;}
				
				if (args[i].equals("-q"))
					{this.Silent = Boolean.parseBoolean(args[++i]);
					params++;
					continue;}
			
								
			}
			if (params < 16){
				System.out.print("WARNING::");
				System.out.println("There appear to be too few parameters");
				System.out.println("Expected minumum number of params is 16 "+" Number parsed is "+params);
			}
			
			// Now we cat this mess together to make a command for LHSMaster. We will also do some checking here
			// to make sure we have the necessary parameters to run!
//			String maincom="";
			
			//Some important checking
			if (Tfile==null){
				System.out.println("Temperature file (\"-T\") Required. Exiting.");
				System.exit(0);
			}
			else{
				// check if readable
				File f = new File(Tfile);
				if (f.exists()==false){
					System.err.println("Temperature file (\"-T\") not found or not readable. Exiting.");
					System.exit(-1);
				}
				
			}
			
//			if (Ni<1){
//				System.out.println("-Ni set to unusable value. Exiting.");
//				System.exit(0);
//			}
			
			LinkedList<String> OptionNames = new LinkedList<String>();
			LinkedList fixed = new LinkedList();
			
			OptionNames.add("-T");	//REQUIRED
			fixed.add(Tfile);
			OptionNames.add("-Tskip");	//defaults to 0
			fixed.add(Tfile_skiplines);
			//OptionNames.add("-Ni");	//REQUIRED
			//fixed.add(Ni);
			OptionNames.add("-rvar"); //REQUIRED
			fixed.add(rvar);
			OptionNames.add("-R");	//REQUIRED
			fixed.add(R);
			OptionNames.add("-tdm"); //optional
			fixed.add(tempDepMortality);
			OptionNames.add("-Sai"); //optional
			fixed.add (SterileAfterIntervention);
			OptionNames.add("-Mx");//optional
			fixed.add (MaxFlies);
//			if (StableDist!=null){
//				OptionNames.add("-Ad");//optional
//				fixed.add (StableDist);
//			}
			if (seed!=0){
				OptionNames.add("-seed");//optional
				fixed.add (seed);
			}
			
			OptionNames.add("-Dm");//optional
			fixed.add (DevModel);
			OptionNames.add("-TuSD");//optional
			fixed.add (TuSD);
			OptionNames.add("-Tmax");//optional
			fixed.add (Tmax);
			OptionNames.add("-q");//optional, set to true
			fixed.add (true);
			OptionNames.add("-pm");// must be true for medfoesp
			fixed.add(true);
			
			//@TG adding in fixed TG options
			if(tgTrue==true){
				OptionNames.add("-tg"); //optional
				fixed.add (tgTrue);
				OptionNames.add("-tgf"); //optional
				fixed.add (tgFile);
				OptionNames.add("-tgi"); //optional
				fixed.add (tgIter);
				OptionNames.add("-tgl"); //optional
				fixed.add (tgLimit);
			}
			
			//@TG, ending TG fixedoption
			
			//if (SterileAfterIntervention==true){
			//	fixed.add(SterileAfterIntervention);
			//}
			
			LinkedList<String []> variable = new LinkedList<String[]>();
			OptionNames.add("-Ni");
			variable.add(DoubleArrayToStringArray(NiV));
			OptionNames.add("-Me");
			variable.add(DoubleArrayToStringArray(MeV));
			OptionNames.add("-Ma");
			variable.add(DoubleArrayToStringArray(MaV));
			OptionNames.add("-Ml");
			variable.add(DoubleArrayToStringArray(MlV));
			OptionNames.add("-Mp");
			variable.add(DoubleArrayToStringArray(MpV));
			OptionNames.add("-TEL");
			variable.add(DoubleArrayToStringArray(TELV));
			OptionNames.add("-TPA");
			variable.add(DoubleArrayToStringArray(TPAV));
			OptionNames.add("-TIM");
			variable.add(DoubleArrayToStringArray(TIMV));
			variable.add(DoubleArrayToStringArray(TLPV));
			OptionNames.add("-TLP");
			OptionNames.add("-r");
			variable.add(DoubleArrayToStringArray(rV));
			OptionNames.add("-rred");
			variable.add(DoubleArrayToStringArray(rredV));
			OptionNames.add("-S");
			variable.add(DoubleArrayToStringArray(SV));
			
			//@TG- adding in variable D
			if(tgTrue==true){
				OptionNames.add("-tgd");
				variable.add(DoubleArrayToStringArray(tgDV));
			}
			
			//@TG end variable D entry
			
		    ListIterator itr = fixed.listIterator();
		    ListIterator itr2 = variable.listIterator();
		    ListIterator optitr=OptionNames.listIterator();
		    
			// cat all together into a String, write to file:

		    String maincom =new String();
		    while(itr.hasNext())
		    {
		    	maincom+=(optitr.next()+"\t");
		    	maincom+=(itr.next()+"\n");
		    }
			
		    while(itr2.hasNext())
		    {
		    	maincom+=(optitr.next()+"\t");
		    	maincom+=(ArrayToString((String[]) itr2.next())+"\n");
		    }

		    WriteStringToFile(maincom,o,"LHS_infile_"+shortStartTime+".txt");
			this.lhscommand=new String[]{String.valueOf(nRuns),"medfoes.jar",o+"LHS_infile_"+shortStartTime+".txt","-o "+o+"Runs/run"};
			
			// Load / compute shared parameters
			// @TCC TODO add more here
			this.T = Utilities.getTempsFromFile(this.Tfile, this.Tfile_skiplines);
			
	//		System.out.println(ArrayToString(lhscommand));
			
		}
		
		private String ArrayToString(String[]s){
			String out = new String();
			for (int i=0;i<s.length;i++){
				out+=s[i]+",";
			}
			return (out.substring(0, out.length()-1)+" ");
			
		}
		
		private String [] DoubleArrayToStringArray(double [] d){
			String [] out = new String[d.length];
			for (int i=0;i<d.length;i++){
				out[i]=Double.toString(d[i]);
			}
			return (out);
			
		}
		
//		private String [] IntArrayToStringArray(int [] d){
//			String [] out = new String[d.length];
//			for (int i=0;i<d.length;i++){
//				out[i]=Integer.toString(d[i]);
//			}
//			return (out);
//			
//		}
//		
		private String [] LongArrayToStringArray(long [] d){
			String [] out = new String[d.length];
			for (int i=0;i<d.length;i++){
				out[i]=Long.toString(d[i]);
			}
			return (out);
			
		}
		
		private void WriteStringToFile(String s,String location, String filename){
			
			if (this.o==null==false){
				// write to files
				try {
					BufferedWriter bws = new BufferedWriter(new FileWriter(location+filename));
					bws.write(s);
					bws.close();
				} catch (IOException e) {
					System.err.println("ERROR writing LHS param file");
					e.printStackTrace();
					System.exit(-1);
				}
			}
			
		}

		
	    private String getDateTime() {
	        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	        Date date = new Date();
	        return dateFormat.format(date);
	    }
	    
	    private void WriteSummaryFile(){
	    	String out = "";
			out+="MED-FOESp version "+version+" summary\n";
			out+="---------------------------------\n";
			out+="\nGENERAL\n";
			out+="Run started on\t"+StartTime+"\n";
			
			out+="Run completed on: "+getDateTime()+"\n";
			if(this.o==null==false){
				out+="This file name: "+o+"MED-FOESp_"+shortStartTime+"_summary.txt"+"\n";
				out+="All run data: "+o+"Runs"+"\n";
			}
			out+="Maximum number of flies permitted: "+MaxFlies+"\n";
			out+="Number of threads (processes): "+nThreads+"\n";
		//	out+="seed used: "+seed+"\n";
			
			out+="\nRESULTS\n";
			out+="Number of simulations run: "+nRuns+"\n";
			out+="Number of simulations completed: "+r.resultNumber+"\n";
			String[]means=r.getMeanRunLengthAndNumbers();
			out+="Percentage of simulations showing extirpation:\t\t"+r.getPercentExtirpation()+"\n";
			out+="Mean number flies at end of simulations (mean[SD]):\t"+means[1]+"\n";
			out+="Mean simulation run length (days: mean[SD]):\t\t"+means[0]+"\n\n";
			out+="Run length percentiles (days):\n";
			out+="99%\t"+r.getTimePercentiles(99)+"\n";
			out+="95%\t"+r.getTimePercentiles(95)+"\n";
			out+="50%\t"+r.getTimePercentiles(50)+"\n";
			out+="25%\t"+r.getTimePercentiles(25)+"\n";
			
			
//			out+="Number of hourly temps read: "+T.length+"\n";
//			out+="Number of hours simulated: "+hours+"\n";
//			out+="Number of Flies at end of simulation: "+p.Flies.size()+"\n";
//			out+="Cumulative number of eggs: "+p.eggsLaid+"\n";
//			out+="Cumulative number of deaths: "+p.deadFlies+"\n";
//			//out+="Cumulative number of eggs: "+cumulativeBirthsDeaths[(hours/24)-1][0]+"\n";
//			//out+="Cumulative number of deaths: "+cumulativeBirthsDeaths[(hours/24)-1][1]+"\n";
//			
			out+="\nPARAMETERS\n";
			out+=" Ni: "+NiV[0]+","+NiV[1]+"\n R: "+R+"\n S(range): "+SV[0]+","+SV[1]+
			"\n TEL(range): "+TELV[0]+","+TELV[1]+","+TELV[2]+","+TELV[3]+"\n TLP(range): "+TLPV[0]+","+TLPV[1]+","+TLPV[2]+","+TLPV[3]+"\n TPA(range): "+TPAV[0]+","+TPAV[1]+","+TPAV[2]+","+TPAV[3]+
			"\n TIM(range): "+TIMV[0]+","+TIMV[1]+","+TIMV[2]+","+TIMV[3]+
			"\n Me(range): "+MeV[0]+","+MeV[1]+"\n Ml(range): "+MlV[0]+","+MlV[1]+"\n Mp(range): "+MpV[0]+","+MpV[1]+"\n Ma(range): "+MaV[0]+","+MaV[1]+
			"\n r(range): "+rV[0]+","+rV[1]+"\n rvar: "+rvar+"\n rred(range): "+rredV[0]+","+rredV[1]+"\n Tmax: "+Tmax+
			"\n Dm: "+DevModel+"\n Sai: "+SterileAfterIntervention+"\n tdm: "+tempDepMortality+"\n TuSD: "+TuSD
			+"\n T: "+Tfile+"\n Tskip: "+Tfile_skiplines;
			try {
				out+="\n Initial Age distribution: ";
				for (int k=0;k<StableDist.length;k++){
					out+=StableDist[k]+"\t";
				}
			}
			catch (Exception e){
				out+="Program default";
			}
			
			if (tgTrue==true){
				out+="\n tg: true";
				out+="\n tgf: "+tgFile+"\n tgi: "+tgIter+"\n tgl: "+tgLimit+"\n tgd (range): "+tgDV[0]+","+tgDV[1];
			}
			else{
				out+="\n No spatial component";
			}
			
			out+="\n\nCITATION:\n"+"Manoukis, NC and Hoffman, K. 2013. An Agent-Based Simulation"+
			" of Extirpation of Ceratitis capitata Applied to Invasions in California . Journal of Pest Science, In Press. DOI: 10.1007/s10340-013-0513-y";
			try {
				BufferedWriter bws = new BufferedWriter(new FileWriter(o+"MED-FOESp_"+shortStartTime+"_summary.txt"));
				bws.write(out);
				bws.close();
			} catch (IOException e) {
				System.err.println("ERROR in medfoesp::WriteSummary: failed to create file "+o+"MED-FOESp_"+shortStartTime+"_summary.txt"+" as summary output file");
				e.printStackTrace();
				System.exit(-1);
			}
	    	
	    }

	    /**
	     * Write a text file with the final results from each simulation (ResultsHolder data)
	     */
	    private void WriteDetailFile(){
	    	String out="";
			try {
				BufferedWriter bws = new BufferedWriter(new FileWriter(o+"MED-FOESp_"+shortStartTime+"_detail.txt"));
				bws.write("run_time\tend_condition\tend_flies\n");
				for( int i=0; i<r.resultNumber; ++i ){
					out = ""+(int)r.times[i]+"\t"
							+r.end_conditions[i]+"\t"
							+(int)r.numbers[i]+"\n";
					bws.write(out);
				}
				bws.close();
			} catch (IOException e) {
				System.err.println("ERROR in medfoesp::WriteSummary: failed to create file "+o+"MED-FOESp_"+shortStartTime+"_summary.txt"+" as summary output file");
				e.printStackTrace();
				System.exit(-1);
			}
	    }
	    
	    
	    /**
	     * Read in a text file, return a String array with each element equal to a line in the original file.
	     * 
	     * @param filename input file name
	     * @return Array with each element equal to one line from file
	     * @throws IOException 
	     */
	    public String[] readLines(String filename) throws IOException   
	    {  
	        FileReader fileReader = new FileReader(filename);  
	          
	        BufferedReader bufferedReader = new BufferedReader(fileReader);  
	        List<String> lines = new ArrayList<String>();  
	        String line = null;  
	          
	        while ((line = bufferedReader.readLine()) != null)   
	        {  
	            lines.add(line);  
	        }  
	          
	        bufferedReader.close();  
	          
	        return lines.toArray(new String[lines.size()]);  
	    }  
}
