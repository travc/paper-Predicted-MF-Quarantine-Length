guiLiner: Configurable and Extensible Graphical User Interface for Biological
Analysis Software

by: N.C. Manoukis with contributions from E.C. Anderson
manoukisn@niaid.nih.gov
--------------------

VERSION INFORMATION

Version 0.3.1
-------------
May 2008

PURPOSE:
The computer programs most users interact with on a daily basis are driven by a 
graphical user interfaces (GUIs). These users often find command-line programs 
hard to use. Programs that can be run on the command line retain certain 
advantages, however, such as being executed though a batch file and easy 
retention of program execution options. This tension between ease of use and 
flexibility is often evident in programs used for scientific computation of data
analysis.

guiLiner was created as a "wrapper" or "host" for population genetic analysis 
programs. It can, however, be used to host almost any command line program. On 
its own, guiLiner is likely to be most useful to computer software developers. 
Once configured to work with particular programs, guiLiner will be used by 
end-users, hopefully without their knowing too much about it.

To summarize what this project is about: guiLiner creates a GUI for command- 
line programs. 

SYSTEM REQUIREMENTS:
guiLiner was written in Java and is distributed as an executable jar file with
source and other information, including samples. It works with JRE 1.5.0 or 
higher (J2SE 5.0); it may also work with earlier versions, but it has not 
been tested with them. guiLiner also utilizes the JDOM library 
(http://www.jdom.org}), which is included in binary form in the lib/ directory 
of the guiLiner program directory. 

STARTING THE PROGRAM:
guiLiner may be run from the command line or by double clicking on most
systems with a JRE installed (see above). Its behavior when started may be of
three types:

   1. If started with a single argument which is the path to a valid XML file
       then guiLiner will immediately start up in user mode.
   2. If it is started without any arguments (such as by double-clicking) a di-
       alog will appear which allows you to select an XML file containing the
       information on a hosted program.
   3. If started with more than one argument (usually from a command line),
       guiLiner will output a usage message to the console and exit.

If you are a developer and would like users to have a seamless experience
starting guiLiner and running your program you may want to include a script
that starts guiLiner and specifies the XML file directly and instruct users to use
it rather than start guiLiner on its own.

DTD:

As of version 0.2 there is a Document Type Definition (DTD) included in the
guiLiner distribution. You can find this in the XML directory. 

SAMPLE XML FILES:
A few XML files are provided in the distribution archive as samples. They are:

spip.xml: 	Config file for spip, a simulation program of genetic trasmission
under variable demography and structure. See 
http://swfsc.noaa.gov/textblock.aspx?Division=FED&id=3434
for more information.
Reference- Anderson, E. and Dunham, K. (2005).
SPIP 1.0: A program for simulating pedigrees and genetic data in
  age-structured populations.
Molecular Ecology Notes, 5(2) 459--461

exonerate.xml:	Config file for exonerate, a generic sequence alignment tool. See
http://www.ebi.ac.uk/~guy/exonerate/ for more information
Reference- Slater, G. S.~C. and Birney, E. (2005).
Automated generation of heuristics for biological sequence
  comparison.
BMC Bioinformatics, 6 31.

im.xml: Config file for IM, a program for the fitting of an isolation model with
migration to haplotype data drawn from two closely related species or populations
See http://lifesci.rutgers.edu/~heylab/HeylabSoftware.htm#IM for more information.
Reference- Hey, J. and Nielsen, R. (2004).
Multilocus methods for estimating population sizes, migration rates
  and divergence time, with applications to the divergence of Drosophila
  pseudoobscura and D. persimilis.
Genetics,167(2) 747--760.

ms.xml: Config file for R. Hudson's makesamples program.
Reference- Hudson, R.~R. (2002).
Generating samples under a Wright-Fisher neutral model of genetic
  variation.
Bioinformatics, 18(2) 337--338.


FURTHER INFORMATION:
Please refer to the user manual guiliner_manual.pdf, which is included in the 
distribution archive.

LICENSING AND ATTRIBUTION:
If you use guiLiner we would be very pleased to hear about it and about your
experiences. We plan a paper describing guiLiner and its capabilities; citing
this paper if you make use of the program would be appreciated. Contact 
information for the authors and details on the paper will be available on the 
project website, at http://guiliner.sourceforge.net

guiLiner is the product of work on US Government time and machines. It is
released into the Public Domain with the disclaimer from the The MIT licence,
which is listed below:

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the ``Software''), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

