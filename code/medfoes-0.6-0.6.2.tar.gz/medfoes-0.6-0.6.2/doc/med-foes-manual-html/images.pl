# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/r_{red};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img57.png"
 ALT="$r_{red}$">|; 

$key = q/t;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="10" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$t$">|; 

$key = q/Ad;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img68.png"
 ALT="$Ad$">|; 

$key = q/(x,y);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="41" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img33.png"
 ALT="$(x,y)$">|; 

$key = q/lambda;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="$\lambda$">|; 

$key = q/1slashd;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="$1/d$">|; 

$key = q/1x10^4;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img60.png"
 ALT="$1x10^4$">|; 

$key = q/t_S;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img54.png"
 ALT="$t_S$">|; 

$key = q/a;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="$a$">|; 

$key = q/{displaymath}K=frac{1}{b}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="38" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="\begin{displaymath}
K=\frac{1}{b}
\end{displaymath}">|; 

$key = q/sigma_x=sigma_y=sigma;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="90" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img51.png"
 ALT="$\sigma_x=\sigma_y=\sigma$">|; 

$key = q/{displaymath}frac{dN(x,y,t)}{dt}=Dleft[frac{d^2N}{dx^2}+frac{d^2N}{dy^2}right]{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="212" HEIGHT="45" BORDER="0"
 SRC="|."$dir".q|img43.png"
 ALT="\begin{displaymath}
\frac{dN(x,y,t)}{dt} = D \left[ \frac{d^2N}{d x^2}
+\frac{d^2N}{d y^2}\right]
\end{displaymath}">|; 

$key = q/T;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$T$">|; 

$key = q/(x_t,y_t);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="$(x_t,y_t)$">|; 

$key = q/t=12;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="47" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="$t=12$">|; 

$key = q/Ni;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img59.png"
 ALT="$Ni$">|; 

$key = q/r;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img55.png"
 ALT="$r$">|; 

$key = q/cor(x,y)=0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img52.png"
 ALT="$cor(x,y) = 0$">|; 

$key = q/T_{min};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="$T_{min}$">|; 

$key = q/^2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img53.png"
 ALT="$^2$">|; 

$key = q/mu=0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img49.png"
 ALT="$\mu = 0$">|; 

$key = q/T_n;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="$T_n$">|; 

$key = q/{displaymath}T_{min}=-frac{a}{b}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="78" HEIGHT="35" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="\begin{displaymath}
T_{min}=-\frac{a}{b}
\end{displaymath}">|; 

$key = q/TuSD;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img66.png"
 ALT="$TuSD$">|; 

$key = q/p_t;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img42.png"
 ALT="$p_t$">|; 

$key = q/sech(lambdad);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="65" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img39.png"
 ALT="$sech(\lambda d)$">|; 

$key = q/d;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$d$">|; 

$key = q/{displaymath}f(d,lambda)=frac{2e^{lambdad}}{1+e^{2lambdad}}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="125" HEIGHT="43" BORDER="0"
 SRC="|."$dir".q|img38.png"
 ALT="\begin{displaymath}
f(d,\lambda)=\frac{2e^{\lambda d}}{1+e^{2 \lambda d}}
\end{displaymath}">|; 

$key = q/N;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img44.png"
 ALT="$N$">|; 

$key = q/{displaymath}H(d)=frac{1}{1+e^{-2lambdad}}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="125" HEIGHT="40" BORDER="0"
 SRC="|."$dir".q|img37.png"
 ALT="\begin{displaymath}
H(d)=\frac{1}{1+e^{-2 \lambda d}}
\end{displaymath}">|; 

$key = q/Mslash24;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img63.png"
 ALT="$M/24$">|; 

$key = q/M_x;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="$M_x$">|; 

$key = q/gamma;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$\gamma$">|; 

$key = q/sigma=4sqrt{Dt};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="76" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img50.png"
 ALT="$\sigma=4\sqrt{Dt}$">|; 

$key = q/includegraphics[width=5in]{mfp};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="574" HEIGHT="552" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img61.png"
 ALT="\includegraphics[width=5in]{mfp}">|; 

$key = q/1slashlambda=;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="47" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$1/\lambda =$">|; 

$key = q/x,y;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img45.png"
 ALT="$x,y$">|; 

$key = q/sigma;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img48.png"
 ALT="$\sigma$">|; 

$key = q/^o;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="$^o$">|; 

$key = q/r_{var};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img56.png"
 ALT="$r_{var}$">|; 

$key = q/sech;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="35" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img40.png"
 ALT="$sech$">|; 

$key = q/K;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$K$">|; 

$key = q/{displaymath}T(t)=left{array{{lc}T_{x,i-1}Gamma(t)+T_{n,i}[1-Gamma(t)]&0<tle5T_{{x,i}Gamma(t)+T_{n,i+1}[1-Gamma(t)]&14<t<24array{right.{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="348" HEIGHT="64" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="\begin{displaymath}
T(t)=\left\{
\begin{array}{l c}
T_{x,i-1}\Gamma(t)+T_{n,i}...
...\Gamma(t)+T_{n,i+1}[1-\Gamma(t)] &amp; 14&lt;t &lt;24
\end{array}\right.
\end{displaymath}">|; 

$key = q/M_x^{1slash24};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="$M_x^{1/24}$">|; 

$key = q/omega=pislash12;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="70" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="$\omega=\pi/12$">|; 

$key = q/{displaymath}Gamma(t)=0.44-0.46sin(omegat+0.9)+0.11sin(2omegat+0.9){displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="361" HEIGHT="28" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="\begin{displaymath}
\Gamma(t)=0.44-0.46sin(\omega t+0.9)+0.11 sin (2 \omega t+0.9)
\end{displaymath}">|; 

$key = q/i;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="10" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="$i$">|; 

$key = q/{displaymath}frac{1}{d}=a+bT{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="79" HEIGHT="38" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\begin{displaymath}
\frac{1}{d} = a + bT
\end{displaymath}">|; 

$key = q/d=sqrt{(x_t-x)^2+(y_t-y)^2};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="193" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="$d=\sqrt{(x_t-x)^2+(y_t-y)^2}$">|; 

$key = q/{displaymath}p=f(d,lambda)=lambdae^{-lambdad}H(d){displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="173" HEIGHT="28" BORDER="0"
 SRC="|."$dir".q|img36.png"
 ALT="\begin{displaymath}
p = f(d,\lambda)=\lambda e^{-\lambda d} H(d)
\end{displaymath}">|; 

$key = q/D;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img46.png"
 ALT="$D$">|; 

$key = q/C;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="$C$">|; 

$key = q/=1slashd;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="$=1/d$">|; 

$key = q/{displaymath}C+gamma<sum_{t=0}^{i}T_i-T_{min}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="154" HEIGHT="56" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="\begin{displaymath}
C+\gamma&lt;\sum_{t=0}^{i} T_i-T_{min}
\end{displaymath}">|; 

$key = q/T_x;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="$T_x$">|; 

$key = q/d>=0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img34.png"
 ALT="$d&gt;=0$">|; 

$key = q/Dm;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img65.png"
 ALT="$Dm$">|; 

$key = q/R;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="$R$">|; 

$key = q/{displaymath}g(x,y)=frac{1}{2pisigma^2}e^{-frac{1}{2}(frac{x^2}{sigma^2}+frac{y^2}{sigma^2})}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="184" HEIGHT="38" BORDER="0"
 SRC="|."$dir".q|img47.png"
 ALT="\begin{displaymath}
g(x,y) = \frac{1}{2\pi \sigma^2}e^{-\frac{1}{2}(\frac{x^2}{\sigma^2}+\frac{y^2}{\sigma^2})}
\end{displaymath}">|; 

$key = q/x;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="$x$">|; 

$key = q/b;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="$b$">|; 

$key = q/includegraphics[width=4in]{transitions_params2};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="460" HEIGHT="306" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics[width=4in]{transitions_params2}">|; 

$key = q/H(d);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img35.png"
 ALT="$H(d)$">|; 

$key = q/M^{1slash24};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img64.png"
 ALT="$M^{1/24}$">|; 

$key = q/Tmax;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img67.png"
 ALT="$Tmax$">|; 

1;

