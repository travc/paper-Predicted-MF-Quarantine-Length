#!/usr/bin/env bash

#COMP_VERSION=0.6
#COMP_VERSION=3fbef1
#COMP_VERSION=foo
COMP_VERSION=dev_0.6.0

declare -a FILES=(
"test_me_1.cfg"
"test_me_1_out_detail.txt"
"test_me_1_out_summary.txt"
)

for ((i = 0; i < ${#FILES[@]}; i++))
do
    F="${FILES[$i]}"
    echo "#### $F ####"
    diff "$F" "${COMP_VERSION}/$F"
done
