@travc Changes

Added -Tskip option to skip first however many lines in the temperature file
Changes only to Medfoesp.java and Simulation.java

Changed output in days to hours

MedFoesP outputs a 'detail' file which lists info about each run (one per line).
Currently just contains:
* time (hour) at end of run
* end condition [0=Extirpation, 1=Out of temperatures, 2=Too many flies]
* number of flies at end of run 

#### Tag 0.6.2 ####




Orginal README below....
____________________________________________________________________
<pre>
A simple description of all the directories in the MED-FOES 
archive:

+bin
  |
  +temperature-estimator.jar		stand alone program for estimating hourly temps from daily min-max
  +med-foes.jar				simulation executable
  +lhs-master.jar			stand alone program for using LHS with MED-FOES
  +med-foes-p.jar			MED-FOES_p executable

+doc
  |
  +apache-commons-math_LICENSE.txt	Apache commons-math license
  +med-foes_manual.pdf			manual and refernce, pdf format
  +med-foes-manual-html/		manual and refernce, html format
  +med-foes_lic.txt			med-foes license
  +javadoc				API documentation
   |
   +(API documentation)
  +IzPack_lic.txt			izPack license
  +Manoukis2013Agent.pdf		Manoukis and Hoffman (2013) paper
  +guiLiner_README.txt			readme for guiLiner
  +CHANGELOG.txt			med-foes changes
  +docs.txt				shortcut destination for docs
  +xchart_LICENSE.txt			xChart license
  +trapgrid_lic.txt			TrapGrid license

+guiLiner_0.4.jar			guiLiner executable

+guiliner.dtd				DTD for guiliner

+lib
  |
  +commons-math3-3.2.jar		Apache commons-math library
  +jdom.jar				jdom library (for guiLiner)
  +xchart-2.2.1.jar			xChart library
  +TrapGrid.jar			TrapGrid library

+med-foes.xml				main med-foes/guiLiner config XML file

+med-foes_original.xml			copy of main med-foes/guiLiner config XML file

+med-foes-p.xml				main med-foes_p/guiLiner config XML file

+med-foes-p_original.xml		copy of main med-foes_p/guiLiner config XML file

+README					this file

+samples				directory with samples
  |
  +station99_sample.csv			temperature data from Santa Monica
  +samples.txt				shortcut destination for samples
  +sample_settings_med-foes.xml		sample settings for MED-FOES (except T)
  +sample_settings_med-foes_p.xml	sample settings for MED-FOES_p (except T,o)
  +lhs-master-infile.txt		sample LHS infile
  +mfp_infile_sample.txt		sample med-foes_p infile
  +infile_sample.txt			sample med-foes infile
  +five_trap_grid.tsv			sample trap grid
  +five_trap_grid_hi.tsv		sample trap grid2, high attraction
  +5mi_sq_eradication_grid.tsv		sample 5x5mi eradication trap grid
  +constant.csv				constant temperature sample file

+src
  |
  + (source code)

+start_mf_gui.bat			MS Windows batch file for starting med-foes GUI

+start_mfp_gui.bat			MS Windows batch file for starting med-foes_p GUI

+start_mf_gui.sh			*nix shell script for starting med-foes GUI

+start_mfp_gui.sh			*nix shell script for starting med-foes_p GUI



For more information, look in the directory labeled 'docs'




NCM
March 2012, updated June 2015
</pre>
