java -jar guiLiner_0.4.jar med-foes.xml
